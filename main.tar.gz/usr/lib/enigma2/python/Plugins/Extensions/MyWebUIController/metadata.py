PLUGIN_NAME = "MyWebUIController"
PLUGIN_VERSION = "1.3.0"
PLUGIN_DESCRIPTION = "Web UI controller for subscription editors of multiple Enigma2 plugins"
