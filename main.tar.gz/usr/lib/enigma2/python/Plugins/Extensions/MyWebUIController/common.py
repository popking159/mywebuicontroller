#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared errors used by MyWebUIController plugin modules."""


class ControllerError(Exception):
    """Base class for errors that can be shown safely in the receiver or web UI."""


class ValidationError(ControllerError):
    pass


class DataStoreError(ControllerError):
    pass


class RevisionConflict(ControllerError):
    pass


class NotFoundError(ControllerError):
    pass
