#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""IPaudioPlus JSON adapter for MyWebUIController.

IPaudioPlus stores grouped user channels in:
    /etc/enigma2/ipaudioplus_user_list.json

The root JSON object preserves group order. Each group contains its external ``Id``
and a ``channels`` list. Channel order is preserved inside each group. Unknown JSON
keys are retained during load/save so plugin-specific fields are not discarded.
"""

from __future__ import print_function

import fcntl
import hashlib
import json
import os
import re
import secrets
import tempfile
import threading
from collections import OrderedDict
from contextlib import contextmanager
from datetime import datetime
from os.path import basename, dirname, exists, join, realpath
from urllib.parse import urlparse

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigText, getConfigListEntry
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import DataStoreError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, detail_skin, list_skin, load_supported_plugin_pixmap


PLUGIN_ID = "ipaudioplus"
PLUGIN_NAME = "IPaudioPlus"
PLUGIN_VERSION = "1.0.0-module1"
PLUGIN_DESCRIPTION = "Edit grouped channels in /etc/enigma2/ipaudioplus_user_list.json"
PLUGIN_WEB_PATH = "/ipaudioplus/"
ASYNC_WEB_ENDPOINTS = set()

SOURCE_PLUGIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/IPaudioPlus/"
SUBSCRIPTION_FILE = "/etc/enigma2/ipaudioplus_user_list.json"
BACKUP_RE = re.compile(r"^ipaudioplus_backup_\d{8}_\d{6}_[a-f0-9]{6}\.json$")
ID_RE = re.compile(r"^[a-f0-9]{32}$")
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_GROUPS = 1000
MAX_CHANNELS_PER_GROUP = 10000
MAX_TEXT = 8192
LOCK = threading.RLock()


def clean_text(value, field, required=True, max_len=MAX_TEXT):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    if "\x00" in value or "\r" in value or "\n" in value:
        raise ValidationError("%s contains invalid characters" % field)
    return value


def validate_channel_url(value):
    value = clean_text(value, "Channel URL", required=True, max_len=MAX_TEXT)
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        raise ValidationError("Channel URL must be a valid http:// or https:// URL")
    return value


def make_id(*parts):
    payload = "\x00".join(str(part) for part in parts).encode("utf-8", "replace")
    return hashlib.md5(payload).hexdigest()


def make_browser_id():
    return secrets.token_hex(16)


def _safe_extra(value, field, excluded):
    if value is None:
        return OrderedDict()
    if not isinstance(value, dict):
        raise ValidationError("%s must be an object" % field)
    output = OrderedDict()
    for key, item in value.items():
        key = clean_text(key, "%s key" % field, required=True, max_len=256)
        if key in excluded:
            continue
        output[key] = item
    try:
        json.dumps(output, ensure_ascii=False)
    except Exception:
        raise ValidationError("%s contains values that cannot be saved as JSON" % field)
    return output


def normalize_channel(item, position=0, group_name=""):
    if not isinstance(item, dict):
        raise ValidationError("Each IPaudioPlus channel must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    name = clean_text(item.get("name", ""), "Channel name", required=True, max_len=512)
    channel_id = clean_text(item.get("channel_id", ""), "Channel ID", required=True, max_len=512)
    url = validate_channel_url(item.get("url", ""))
    internal_id = raw_id if ID_RE.match(raw_id) else make_id(group_name, position, name, channel_id, url)
    return {
        "id": internal_id,
        "name": name,
        "channel_id": channel_id,
        "url": url,
        "extra": _safe_extra(item.get("extra"), "Channel extra fields", ("id", "name", "channel_id", "url", "extra", "Name", "Id", "Url")),
    }


def normalize_group(item, position=0):
    if not isinstance(item, dict):
        raise ValidationError("Each IPaudioPlus group must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    name = clean_text(item.get("name", ""), "Group name", required=True, max_len=512)
    group_id = clean_text(item.get("group_id", ""), "Group ID", required=True, max_len=512)
    channels = item.get("channels", [])
    if not isinstance(channels, list):
        raise ValidationError("Channels for group %s must be a list" % name)
    if len(channels) > MAX_CHANNELS_PER_GROUP:
        raise ValidationError("Too many channels in group %s" % name)
    internal_id = raw_id if ID_RE.match(raw_id) else make_id(position, name, group_id)
    normalized_channels = [normalize_channel(channel, index, name) for index, channel in enumerate(channels)]
    seen_channel_ids = set()
    for channel in normalized_channels:
        key = channel["channel_id"].casefold()
        if key in seen_channel_ids:
            raise ValidationError("Duplicate channel ID in group %s: %s" % (name, channel["channel_id"]))
        seen_channel_ids.add(key)
    return {
        "id": internal_id,
        "name": name,
        "group_id": group_id,
        "channels": normalized_channels,
        "extra": _safe_extra(item.get("extra"), "Group extra fields", ("id", "name", "group_id", "channels", "extra", "Id")),
    }


def normalize_groups(items):
    if not isinstance(items, list):
        raise ValidationError("IPaudioPlus group collection must be a list")
    if len(items) > MAX_GROUPS:
        raise ValidationError("Too many IPaudioPlus groups")
    output = []
    seen_names = set()
    seen_ids = set()
    for index, item in enumerate(items):
        group = normalize_group(item, index)
        name_key = group["name"].casefold()
        id_key = group["group_id"].casefold()
        if name_key in seen_names:
            raise ValidationError("Duplicate IPaudioPlus group name: %s" % group["name"])
        if id_key in seen_ids:
            raise ValidationError("Duplicate IPaudioPlus group ID: %s" % group["group_id"])
        seen_names.add(name_key)
        seen_ids.add(id_key)
        output.append(group)
    return output


def public_channel(item):
    return {
        "id": item["id"],
        "name": item["name"],
        "channel_id": item["channel_id"],
        "url": item["url"],
        "extra": OrderedDict(item.get("extra", {})),
    }


def public_group(item):
    return {
        "id": item["id"],
        "name": item["name"],
        "group_id": item["group_id"],
        "channels": [public_channel(channel) for channel in item.get("channels", [])],
        "extra": OrderedDict(item.get("extra", {})),
    }


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def file_lock(path, exclusive=True):
    lock_path = path + ".lock"
    folder = dirname(lock_path)
    if folder:
        os.makedirs(folder, mode=0o755, exist_ok=True)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write_bytes(path, payload, mode=0o600):
    folder = dirname(path)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".mywebui_ipaudioplus_", suffix=".tmp", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(folder, os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    finally:
        if exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def ensure_files():
    folder = dirname(SUBSCRIPTION_FILE)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    if not exists(SUBSCRIPTION_FILE):
        with file_lock(SUBSCRIPTION_FILE):
            if not exists(SUBSCRIPTION_FILE):
                _atomic_write_bytes(SUBSCRIPTION_FILE, b"{}\n", mode=0o600)
    try:
        os.chmod(SUBSCRIPTION_FILE, 0o600)
    except Exception:
        pass


def parse_json_payload(payload):
    if len(payload) > MAX_FILE_BYTES:
        raise DataStoreError("ipaudioplus_user_list.json is larger than %s MB" % (MAX_FILE_BYTES // (1024 * 1024)))
    try:
        decoded = json.loads(payload.decode("utf-8"), object_pairs_hook=OrderedDict)
    except Exception as exc:
        raise DataStoreError("Invalid JSON in %s: %s" % (SUBSCRIPTION_FILE, exc))
    if not isinstance(decoded, dict):
        raise DataStoreError("ipaudioplus_user_list.json root must be a JSON object")
    if len(decoded) > MAX_GROUPS:
        raise DataStoreError("Too many IPaudioPlus groups")
    groups = []
    for group_index, (group_name, raw_group) in enumerate(decoded.items()):
        try:
            group_name = clean_text(group_name, "Group name", required=True, max_len=512)
        except ValidationError as exc:
            raise DataStoreError(str(exc))
        if not isinstance(raw_group, dict):
            raise DataStoreError("Group %s must be a JSON object" % group_name)
        try:
            group_id = clean_text(raw_group.get("Id", ""), "Group ID", required=True, max_len=512)
        except ValidationError as exc:
            raise DataStoreError("Invalid group %s: %s" % (group_name, exc))
        channels = raw_group.get("channels", [])
        if not isinstance(channels, list):
            raise DataStoreError("Channels for group %s must be a JSON list" % group_name)
        if len(channels) > MAX_CHANNELS_PER_GROUP:
            raise DataStoreError("Too many channels in group %s" % group_name)
        group_extra = OrderedDict((key, value) for key, value in raw_group.items() if key not in ("Id", "channels"))
        public_channels = []
        seen_channel_ids = set()
        for channel_index, raw_channel in enumerate(channels):
            if not isinstance(raw_channel, dict):
                raise DataStoreError("Channel %s in group %s must be a JSON object" % (channel_index + 1, group_name))
            try:
                name = clean_text(raw_channel.get("Name", ""), "Channel name", required=True, max_len=512)
                channel_id = clean_text(raw_channel.get("Id", ""), "Channel ID", required=True, max_len=512)
                url = validate_channel_url(raw_channel.get("Url", ""))
            except ValidationError as exc:
                raise DataStoreError("Invalid channel %s in group %s: %s" % (channel_index + 1, group_name, exc))
            channel_key = channel_id.casefold()
            if channel_key in seen_channel_ids:
                raise DataStoreError("Duplicate channel ID in group %s: %s" % (group_name, channel_id))
            seen_channel_ids.add(channel_key)
            channel_extra = OrderedDict((key, value) for key, value in raw_channel.items() if key not in ("Name", "Id", "Url"))
            public_channels.append({
                "id": make_id(group_index, group_name, group_id, channel_index, name, channel_id, url),
                "name": name,
                "channel_id": channel_id,
                "url": url,
                "extra": channel_extra,
            })
        groups.append({
            "id": make_id(group_index, group_name, group_id),
            "name": group_name,
            "group_id": group_id,
            "channels": public_channels,
            "extra": group_extra,
        })
    return groups


def _encode_groups(groups):
    root = OrderedDict()
    for group in groups:
        group_obj = OrderedDict()
        group_obj["Id"] = group["group_id"]
        for key, value in group.get("extra", {}).items():
            if key not in ("Id", "channels"):
                group_obj[key] = value
        channel_rows = []
        for channel in group.get("channels", []):
            channel_obj = OrderedDict()
            channel_obj["Name"] = channel["name"]
            channel_obj["Id"] = channel["channel_id"]
            channel_obj["Url"] = channel["url"]
            for key, value in channel.get("extra", {}).items():
                if key not in ("Name", "Id", "Url"):
                    channel_obj[key] = value
            channel_rows.append(channel_obj)
        group_obj["channels"] = channel_rows
        root[group["name"]] = group_obj
    payload = (json.dumps(root, ensure_ascii=False, indent=4) + "\n").encode("utf-8")
    if len(payload) > MAX_FILE_BYTES:
        raise ValidationError("ipaudioplus_user_list.json would exceed %s MB" % (MAX_FILE_BYTES // (1024 * 1024)))
    return payload


def _read_unlocked():
    try:
        with open(SUBSCRIPTION_FILE, "rb") as handle:
            payload = handle.read(MAX_FILE_BYTES + 1)
    except Exception as exc:
        raise DataStoreError("Unable to read %s: %s" % (SUBSCRIPTION_FILE, exc))
    return parse_json_payload(payload), payload


def load_groups():
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=False):
        groups, payload = _read_unlocked()
    return groups, sha256_bytes(payload)


def save_groups(items, expected_revision=None):
    groups = normalize_groups(items)
    payload = _encode_groups(groups)
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=True):
        previous, raw = _read_unlocked()
        current_revision = sha256_bytes(raw)
        if expected_revision and expected_revision != current_revision:
            raise RevisionConflict("ipaudioplus_user_list.json changed on the receiver. Reload before saving.")
        _atomic_write_bytes(SUBSCRIPTION_FILE, payload, mode=0o600)
    return load_groups()


def list_backups():
    folder = ensure_backup_dir()
    names = [name for name in os.listdir(folder) if BACKUP_RE.match(name)]
    names.sort(reverse=True)
    return names


def create_backup():
    ensure_files()
    groups, revision = load_groups()
    with open(SUBSCRIPTION_FILE, "rb") as handle:
        payload = handle.read(MAX_FILE_BYTES + 1)
    if len(payload) > MAX_FILE_BYTES:
        raise DataStoreError("ipaudioplus_user_list.json is too large to back up")
    filename = "ipaudioplus_backup_%s_%s.json" % (datetime.now().strftime("%Y%m%d_%H%M%S"), secrets.token_hex(3))
    _atomic_write_bytes(join(ensure_backup_dir(), filename), payload, mode=0o600)
    return filename


def _safe_backup_path(filename):
    filename = clean_text(filename, "Backup filename", required=True, max_len=200)
    if filename != basename(filename) or not BACKUP_RE.match(filename):
        raise ValidationError("Invalid backup filename")
    folder = realpath(ensure_backup_dir())
    candidate = realpath(join(folder, filename))
    if not candidate.startswith(folder + os.sep) or not exists(candidate):
        raise ValidationError("Backup not found")
    return candidate


def restore_backup(filename):
    source = _safe_backup_path(filename)
    with open(source, "rb") as handle:
        payload = handle.read(MAX_FILE_BYTES + 1)
    parse_json_payload(payload)
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=True):
        _atomic_write_bytes(SUBSCRIPTION_FILE, payload, mode=0o600)
    return load_groups()


def load_plugin_pixmap():
    return load_supported_plugin_pixmap("ipaudioplus.png")


def group_description(group):
    count = len(group.get("channels", []))
    return "%s channel%s | ID: %s" % (count, "" if count == 1 else "s", group.get("group_id", ""))


def channel_description(channel):
    return "%s | ID: %s" % (channel.get("url", ""), channel.get("channel_id", ""))


class IPaudioPlusMenuScreen(Screen):
    skin = list_skin("IPaudioPlus Editor %s" % PLUGIN_VERSION, button_count=1, include_info=False, button_names=["Redkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        ensure_files()
        self.pixmap = load_plugin_pixmap()
        self.menu_items = [
            (_("Groups & Channels"), _("Edit /etc/enigma2/ipaudioplus_user_list.json"), "groups"),
            (_("Backup & Restore"), _("Create or restore IPaudioPlus JSON backups"), "backup"),
        ]
        self["menu"] = List([])
        self["Greenkey"] = StaticText("")
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select_item,
            "cancel": self.close,
            "red": self.close,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        self["menu"].setList([(a, b, self.pixmap, c) for a, b, c in self.menu_items])

    def select_item(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if current[3] == "groups":
            self.session.open(GroupListScreen)
        elif current[3] == "backup":
            self.session.open(BackupRestoreScreen)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self.menu_items) - 1:
            self["menu"].setIndex(index + 1)


class GroupListScreen(Screen):
    skin = list_skin("IPaudioPlus Groups", button_count=4, include_info=False)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.groups = []
        self.pixmap = load_plugin_pixmap()
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add Group"))
        self["Yellowkey"] = StaticText(_("Edit Group"))
        self["Redkey"] = StaticText(_("Delete Group"))
        self["Bluekey"] = StaticText(_("Channels"))
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.open_channels,
            "cancel": self.close,
            "green": self.add_group,
            "yellow": self.edit_group,
            "red": self.delete_group,
            "blue": self.open_channels,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_groups)

    def load_groups(self, *args):
        try:
            self.groups, revision = load_groups()
            rows = [(group["name"], group_description(group), self.pixmap, index) for index, group in enumerate(self.groups)]
            if not rows:
                rows = [(_("No IPaudioPlus groups found"), _("Press Add Group to create one"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.groups = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.groups):
            return current[3], self.groups[current[3]]
        return None, None

    def add_group(self):
        self.session.openWithCallback(self.load_groups, EditGroupScreen, "add")

    def edit_group(self):
        index, group = self.selected()
        if group:
            self.session.openWithCallback(self.load_groups, EditGroupScreen, "edit", group, index)

    def delete_group(self):
        index, group = self.selected()
        if group:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete group %s and its channels?" % group["name"], MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            groups, revision = load_groups()
            if index >= len(groups):
                raise ValidationError("IPaudioPlus group no longer exists")
            groups.pop(index)
            save_groups(groups)
            self.load_groups()
            self.session.open(MessageBox, _("IPaudioPlus group deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def open_channels(self):
        index, group = self.selected()
        if group:
            self.session.openWithCallback(self.load_groups, ChannelListScreen, index)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class ChannelListScreen(Screen):
    skin = list_skin("IPaudioPlus Channels", button_count=3, include_info=False, button_names=["Redkey", "Greenkey", "Yellowkey"])

    def __init__(self, session, group_index):
        Screen.__init__(self, session)
        self.group_index = group_index
        self.groups = []
        self.group = None
        self.channels = []
        self.pixmap = load_plugin_pixmap()
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add Channel"))
        self["Yellowkey"] = StaticText(_("Edit Channel"))
        self["Redkey"] = StaticText(_("Delete Channel"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.view_channel,
            "cancel": self.close,
            "green": self.add_channel,
            "yellow": self.edit_channel,
            "red": self.delete_channel,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_channels)

    def load_channels(self, *args):
        try:
            self.groups, revision = load_groups()
            if self.group_index >= len(self.groups):
                raise ValidationError("IPaudioPlus group no longer exists")
            self.group = self.groups[self.group_index]
            self.channels = self.group.get("channels", [])
            self.setTitle("IPaudioPlus Channels - %s" % self.group["name"])
            rows = [(channel.get("name", "Unnamed channel"), channel_description(channel), self.pixmap, index) for index, channel in enumerate(self.channels)]
            if not rows:
                rows = [(_("No channels found"), _("Press Add Channel to create one"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.groups = []
            self.group = None
            self.channels = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.channels):
            return current[3], self.channels[current[3]]
        return None, None

    def view_channel(self):
        index, channel = self.selected()
        if channel:
            self.session.open(ChannelViewScreen, channel)

    def add_channel(self):
        if self.group is not None:
            self.session.openWithCallback(self.load_channels, EditChannelScreen, self.group_index, "add")

    def edit_channel(self):
        index, channel = self.selected()
        if channel:
            self.session.openWithCallback(self.load_channels, EditChannelScreen, self.group_index, "edit", channel, index)

    def delete_channel(self):
        index, channel = self.selected()
        if channel:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete channel %s?" % channel["name"], MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            groups, revision = load_groups()
            if self.group_index >= len(groups):
                raise ValidationError("IPaudioPlus group no longer exists")
            channels = groups[self.group_index].get("channels", [])
            if index >= len(channels):
                raise ValidationError("IPaudioPlus channel no longer exists")
            channels.pop(index)
            save_groups(groups)
            self.load_channels()
            self.session.open(MessageBox, _("IPaudioPlus channel deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class ChannelViewScreen(Screen):
    skin = detail_skin()

    def __init__(self, session, channel):
        Screen.__init__(self, session)
        self.channel = channel
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["DirectionActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)
        self.setTitle("Channel: %s" % channel.get("name", "Unknown"))
        self.onLayoutFinish.append(self.display)

    def display(self):
        lines = ["=" * 60, "IPAUDIOPLUS CHANNEL", "=" * 60]
        lines.append("Name       : %s" % self.channel.get("name", ""))
        lines.append("ID         : %s" % self.channel.get("channel_id", ""))
        lines.append("URL        : %s" % self.channel.get("url", ""))
        self["text"].setText("\n".join(lines))


class EditGroupScreen(Screen, ConfigListScreen):
    skin = config_skin("IPaudioPlus Group Editor")

    def __init__(self, session, mode="add", group=None, group_index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.group_index = group_index
        self.group = dict(group or {})
        self.name = ConfigText(default=self.group.get("name", ""), fixed_size=False)
        self.group_id = ConfigText(default=self.group.get("group_id", ""), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add IPaudioPlus Group") if mode == "add" else _("Edit IPaudioPlus Group"))
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Group Name"), self.name),
            getConfigListEntry(_("Group ID"), self.group_id),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def save_config(self):
        try:
            groups, revision = load_groups()
            if self.mode == "add":
                groups.append({"id": make_browser_id(), "name": self.name.value, "group_id": self.group_id.value, "channels": [], "extra": OrderedDict()})
            else:
                if self.group_index is None or self.group_index >= len(groups):
                    raise ValidationError("IPaudioPlus group no longer exists")
                groups[self.group_index]["name"] = self.name.value
                groups[self.group_index]["group_id"] = self.group_id.value
            save_groups(groups)
            self.session.open(MessageBox, _("IPaudioPlus group saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class EditChannelScreen(Screen, ConfigListScreen):
    skin = config_skin("IPaudioPlus Channel Editor")

    def __init__(self, session, group_index, mode="add", channel=None, channel_index=None):
        Screen.__init__(self, session)
        self.group_index = group_index
        self.mode = mode
        self.channel_index = channel_index
        self.channel = dict(channel or {})
        self.name = ConfigText(default=self.channel.get("name", ""), fixed_size=False)
        self.channel_id = ConfigText(default=self.channel.get("channel_id", ""), fixed_size=False)
        self.url = ConfigText(default=self.channel.get("url", "http://"), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add IPaudioPlus Channel") if mode == "add" else _("Edit IPaudioPlus Channel"))
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Channel Name"), self.name),
            getConfigListEntry(_("Channel ID"), self.channel_id),
            getConfigListEntry(_("Channel URL"), self.url),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def collect(self):
        return {
            "id": self.channel.get("id") or make_browser_id(),
            "name": self.name.value,
            "channel_id": self.channel_id.value,
            "url": self.url.value,
            "extra": OrderedDict(self.channel.get("extra", {})),
        }

    def save_config(self):
        try:
            groups, revision = load_groups()
            if self.group_index >= len(groups):
                raise ValidationError("IPaudioPlus group no longer exists")
            channels = groups[self.group_index].get("channels", [])
            channel = normalize_channel(self.collect(), len(channels), groups[self.group_index]["name"])
            if self.mode == "add":
                channels.append(channel)
            else:
                if self.channel_index is None or self.channel_index >= len(channels):
                    raise ValidationError("IPaudioPlus channel no longer exists")
                channels[self.channel_index] = channel
            save_groups(groups)
            self.session.open(MessageBox, _("IPaudioPlus channel saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("IPaudioPlus Backup & Restore", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Backup ipaudioplus_user_list.json"), _("Create a protected backup of the grouped channel file"), "backup"),
            (_("Restore ipaudioplus_user_list.json"), _("Restore a previous IPaudioPlus JSON backup"), "restore"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        try:
            if current[3] == "backup":
                self.session.open(MessageBox, "Backup created: %s" % create_backup(), MessageBox.TYPE_INFO)
            else:
                choices = [(name, name) for name in list_backups()]
                if not choices:
                    raise ValidationError("No backups found")
                self.session.openWithCallback(self.restore_choice, ChoiceBox, title="Select backup to restore", list=choices)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def restore_choice(self, choice):
        if not choice:
            return
        try:
            restore_backup(choice[1])
            self.session.open(MessageBox, "ipaudioplus_user_list.json restored successfully", MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


def manifest():
    return {
        "id": PLUGIN_ID,
        "name": PLUGIN_NAME,
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(IPaudioPlusMenuScreen)


def web_get(endpoint, args):
    if endpoint == "info":
        payload = manifest()
        payload["success"] = True
        payload["source_plugin_dir"] = SOURCE_PLUGIN_DIR
        payload["subscription_file"] = SUBSCRIPTION_FILE
        return payload
    if endpoint == "groups":
        groups, revision = load_groups()
        return {"success": True, "groups": [public_group(group) for group in groups], "revision": revision}
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise NotFoundError("Unknown IPaudioPlus API endpoint")


def web_post(endpoint, data):
    if not isinstance(data, dict):
        raise ValidationError("JSON request must be an object")
    if endpoint == "update":
        groups, revision = save_groups(data.get("groups", []), expected_revision=data.get("revision"))
        return {"success": True, "groups": [public_group(group) for group in groups], "revision": revision}
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        groups, revision = restore_backup(data.get("backup"))
        return {"success": True, "groups": [public_group(group) for group in groups], "revision": revision}
    raise NotFoundError("Unknown IPaudioPlus API endpoint")
