#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EStalker e-portals.txt adapter for MyWebUIController.

EStalker stores portal blocks in:
    /etc/enigma2/estalker/e-portals.txt

A portal URL line is followed by one or more MAC-address lines.  Each URL + MAC
pair is exposed as one editable server record.  Therefore a block containing
one URL and two MAC addresses represents two servers.
"""

from __future__ import print_function

import fcntl
import hashlib
import os
import re
import secrets
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime
from os.path import basename, dirname, exists, join, realpath
from urllib.parse import urlparse

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigText, getConfigListEntry
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import ControllerError, DataStoreError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, detail_skin, list_skin, load_supported_plugin_pixmap


PLUGIN_ID = "estalker"
PLUGIN_NAME = "EStalker"
PLUGIN_VERSION = "1.2.0-module1-hicons2"
PLUGIN_DESCRIPTION = "Edit the EStalker e-portals.txt subscription file"
PLUGIN_WEB_PATH = "/estalker/"
ASYNC_WEB_ENDPOINTS = set()

PORTAL_FILE = "/etc/enigma2/estalker/e-portals.txt"
BACKUP_RE = re.compile(r"^estalker_backup_\d{8}_\d{6}_[a-f0-9]{6}\.txt$")
ID_RE = re.compile(r"^[a-f0-9]{32}$")
MAC_RE = re.compile(r"^(?:[0-9A-F]{12}|(?:[0-9A-F]{2}:){5}[0-9A-F]{2})$")
MAX_ENTRIES = 2000
MAX_LINE_BYTES = 8192
LOCK = threading.RLock()


def clean_text(value, field, required=True, max_len=4096):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    if "\x00" in value or "\r" in value or "\n" in value:
        raise ValidationError("%s contains invalid characters" % field)
    return value


def validate_portal(value):
    value = clean_text(value, "Portal URL", required=True, max_len=MAX_LINE_BYTES)
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        raise ValidationError("Portal URL must be a valid http:// or https:// URL")
    if parsed.username or parsed.password:
        raise ValidationError("Portal URL must not include embedded credentials")
    if parsed.fragment:
        raise ValidationError("Portal URL must not include a fragment")
    return value


def normalize_mac(value):
    value = clean_text(value, "MAC address", required=True, max_len=17).upper()
    if not MAC_RE.match(value):
        raise ValidationError("MAC address must use 001B79F87B7D or 00:1B:79:F8:7B:7D format")
    compact = value.replace(":", "")
    return ":".join(compact[index:index + 2] for index in range(0, 12, 2))


def make_id(portal, mac, position=0):
    payload = ("%s\x00%s\x00%s" % (position, portal, mac)).encode("utf-8", "replace")
    return hashlib.md5(payload).hexdigest()


def make_browser_id():
    return secrets.token_hex(16)


def normalize_entry(item):
    if not isinstance(item, dict):
        raise ValidationError("Each EStalker server entry must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    entry_id = raw_id if ID_RE.match(raw_id) else make_browser_id()
    return {
        "id": entry_id,
        "portal": validate_portal(item.get("portal", "")),
        "mac": normalize_mac(item.get("mac", "")),
    }


def public_entry(item):
    return dict(item)


def display_name(item):
    return "MAC: %s" % item.get("mac", "Unknown")


def display_description(item):
    return item.get("portal", "")


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def file_lock(path, exclusive=True):
    lock_path = path + ".lock"
    folder = dirname(lock_path)
    if folder:
        os.makedirs(folder, mode=0o755, exist_ok=True)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write_bytes(path, payload, mode=0o600):
    folder = dirname(path)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".mywebui_estalker_", suffix=".tmp", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(folder, os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    finally:
        if exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def ensure_files():
    os.makedirs(dirname(PORTAL_FILE), mode=0o755, exist_ok=True)
    if not exists(PORTAL_FILE):
        with file_lock(PORTAL_FILE):
            if not exists(PORTAL_FILE):
                _atomic_write_bytes(PORTAL_FILE, b"", mode=0o600)
    try:
        os.chmod(PORTAL_FILE, 0o600)
    except Exception:
        pass


def parse_text(text):
    """Parse URL blocks and return one record for every URL + MAC pair."""
    entries = []
    current_portal = None
    for line_number, raw_line in enumerate(text.splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if MAC_RE.match(line.upper()):
            if not current_portal:
                raise DataStoreError("MAC address appears before a portal URL at line %s" % line_number)
            mac = normalize_mac(line)
            entries.append({
                "id": make_id(current_portal, mac, len(entries)),
                "portal": current_portal,
                "mac": mac,
            })
            continue
        try:
            current_portal = validate_portal(line)
        except ValidationError:
            raise DataStoreError("Invalid EStalker portal line %s: %s" % (line_number, line))
    if len(entries) > MAX_ENTRIES:
        raise DataStoreError("Too many EStalker server entries")
    return entries


def _encode_entries(items):
    """Write portal blocks while preserving the editable record order."""
    rows = []
    previous_portal = None
    for item in items:
        portal = item["portal"]
        if portal != previous_portal:
            if rows:
                rows.append("")
            rows.append(portal)
            previous_portal = portal
        rows.append(item["mac"])
    return (("\n".join(rows) + "\n") if rows else "").encode("utf-8")


def _read_unlocked():
    try:
        with open(PORTAL_FILE, "rb") as handle:
            raw = handle.read()
    except Exception as exc:
        raise DataStoreError("Unable to read %s: %s" % (PORTAL_FILE, exc))
    try:
        text = raw.decode("utf-8")
    except Exception as exc:
        raise DataStoreError("Unable to decode %s as UTF-8: %s" % (PORTAL_FILE, exc))
    return parse_text(text), raw


def load_entries():
    ensure_files()
    with LOCK, file_lock(PORTAL_FILE, exclusive=False):
        entries, raw = _read_unlocked()
    return entries, sha256_bytes(raw)


def save_entries(items, expected_revision=None):
    if not isinstance(items, list):
        raise ValidationError("EStalker server collection must be a list")
    if len(items) > MAX_ENTRIES:
        raise ValidationError("Too many EStalker server entries")
    ensure_files()
    with LOCK, file_lock(PORTAL_FILE, exclusive=True):
        previous, raw = _read_unlocked()
        current_revision = sha256_bytes(raw)
        if expected_revision and expected_revision != current_revision:
            raise RevisionConflict("EStalker e-portals.txt changed on the receiver. Reload before saving.")
        normalized = []
        seen = set()
        for item in items:
            entry = normalize_entry(item)
            key = (entry["portal"].casefold(), entry["mac"])
            if key in seen:
                raise ValidationError("Duplicate EStalker portal and MAC pair")
            seen.add(key)
            normalized.append(entry)
        _atomic_write_bytes(PORTAL_FILE, _encode_entries(normalized), mode=0o600)
    return load_entries()


def list_backups():
    folder = ensure_backup_dir()
    names = [name for name in os.listdir(folder) if BACKUP_RE.match(name)]
    names.sort(reverse=True)
    return names


def create_backup():
    ensure_files()
    entries, revision = load_entries()
    with open(PORTAL_FILE, "rb") as handle:
        payload = handle.read()
    filename = "estalker_backup_%s_%s.txt" % (datetime.now().strftime("%Y%m%d_%H%M%S"), secrets.token_hex(3))
    _atomic_write_bytes(join(ensure_backup_dir(), filename), payload, mode=0o600)
    return filename


def _safe_backup_path(filename):
    filename = clean_text(filename, "Backup filename", required=True, max_len=200)
    if filename != basename(filename) or not BACKUP_RE.match(filename):
        raise ValidationError("Invalid backup filename")
    folder = realpath(ensure_backup_dir())
    candidate = realpath(join(folder, filename))
    if not candidate.startswith(folder + os.sep) or not exists(candidate):
        raise ValidationError("Backup not found")
    return candidate


def restore_backup(filename):
    source = _safe_backup_path(filename)
    with open(source, "rb") as handle:
        payload = handle.read()
    try:
        parse_text(payload.decode("utf-8"))
    except ControllerError:
        raise
    except Exception as exc:
        raise DataStoreError("Backup is invalid: %s" % exc)
    with LOCK, file_lock(PORTAL_FILE, exclusive=True):
        _atomic_write_bytes(PORTAL_FILE, payload, mode=0o600)
    return load_entries()


def load_plugin_pixmap():
    """Load the real EStalker icon from images/supportedplugins."""
    return load_supported_plugin_pixmap("estalker.png")


class EStalkerMenuScreen(Screen):
    skin = list_skin("EStalker Editor %s" % PLUGIN_VERSION, button_count=1, include_info=False, button_names=["Redkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        ensure_files()
        self.pixmap = load_plugin_pixmap()
        self.menu_items = [
            (_("Portals"), _("Edit /etc/enigma2/estalker/e-portals.txt"), "portals"),
            (_("Backup & Restore"), _("Create or restore e-portals.txt backups"), "backup"),
        ]
        self["menu"] = List([])
        self["Greenkey"] = StaticText("")
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select_item,
            "cancel": self.close,
            "red": self.close,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        self["menu"].setList([(a, b, self.pixmap, c) for a, b, c in self.menu_items])

    def select_item(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if current[3] == "portals":
            self.session.open(PortalListScreen)
        elif current[3] == "backup":
            self.session.open(BackupRestoreScreen)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self.menu_items) - 1:
            self["menu"].setIndex(index + 1)


class PortalListScreen(Screen):
    skin = list_skin("EStalker Portals", button_count=3, include_info=False, button_names=["Redkey", "Greenkey", "Yellowkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.entries = []
        self.pixmap = load_plugin_pixmap()
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add"))
        self["Yellowkey"] = StaticText(_("Edit"))
        self["Redkey"] = StaticText(_("Delete"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.view_entry,
            "cancel": self.close,
            "green": self.add_entry,
            "yellow": self.edit_entry,
            "red": self.delete_entry,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_entries)

    def load_entries(self, *args):
        try:
            self.entries, revision = load_entries()
            rows = [(display_name(item), display_description(item), self.pixmap, index) for index, item in enumerate(self.entries)]
            if not rows:
                rows = [(_("No EStalker servers found"), _("Press Add to create a portal and MAC record"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.entries = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.entries):
            return current[3], self.entries[current[3]]
        return None, None

    def view_entry(self):
        index, item = self.selected()
        if item:
            self.session.open(EntryViewScreen, item)

    def add_entry(self):
        self.session.openWithCallback(self.load_entries, EditEntryScreen, "add")

    def edit_entry(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(self.load_entries, EditEntryScreen, "edit", item, index)

    def delete_entry(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete EStalker server %s?" % item["mac"], MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            entries, revision = load_entries()
            if index >= len(entries):
                raise ValidationError("EStalker server no longer exists")
            entries.pop(index)
            save_entries(entries)
            self.load_entries()
            self.session.open(MessageBox, _("EStalker server deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class EntryViewScreen(Screen):
    skin = detail_skin("EStalker Server Details")

    def __init__(self, session, entry):
        Screen.__init__(self, session)
        self.entry = entry
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["DirectionActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)
        self.setTitle(display_name(entry))
        self.onLayoutFinish.append(self.display)

    def display(self):
        lines = ["=" * 60, "ESTALKER SERVER DETAILS", "=" * 60]
        for key, value in self.entry.items():
            lines.append("%-15s : %s" % (key, value))
        self["text"].setText("\n".join(lines))


class EditEntryScreen(Screen, ConfigListScreen):
    skin = config_skin("EStalker Portal Editor")

    def __init__(self, session, mode="add", entry=None, entry_index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.entry_index = entry_index
        self.entry = dict(entry or {})
        self.portal = ConfigText(default=self.entry.get("portal", "http://"), fixed_size=False)
        self.mac = ConfigText(default=self.entry.get("mac", ""), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add EStalker Server") if mode == "add" else _("Edit EStalker Server"))
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Portal URL"), self.portal),
            getConfigListEntry(_("MAC Address"), self.mac),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def collect(self):
        return {
            "id": self.entry.get("id") or make_browser_id(),
            "portal": self.portal.value,
            "mac": self.mac.value,
        }

    def save_config(self):
        try:
            item = normalize_entry(self.collect())
            entries, revision = load_entries()
            if self.mode == "add":
                entries.append(item)
            else:
                if self.entry_index is None or self.entry_index >= len(entries):
                    raise ValidationError("EStalker server no longer exists")
                entries[self.entry_index] = item
            save_entries(entries)
            self.session.open(MessageBox, _("EStalker server saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("EStalker Backup & Restore", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Backup e-portals.txt"), _("Create a protected backup of the EStalker subscription file"), "backup"),
            (_("Restore e-portals.txt"), _("Restore a previous EStalker e-portals.txt backup"), "restore"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        try:
            if current[3] == "backup":
                self.session.open(MessageBox, "Backup created: %s" % create_backup(), MessageBox.TYPE_INFO)
            else:
                choices = [(name, name) for name in list_backups()]
                if not choices:
                    raise ValidationError("No backups found")
                self.session.openWithCallback(self.restore_choice, ChoiceBox, title="Select backup to restore", list=choices)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def restore_choice(self, choice):
        if not choice:
            return
        try:
            restore_backup(choice[1])
            self.session.open(MessageBox, "EStalker e-portals.txt restored successfully", MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


def manifest():
    return {
        "id": PLUGIN_ID,
        "name": PLUGIN_NAME,
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(EStalkerMenuScreen)


def web_get(endpoint, args):
    if endpoint == "info":
        payload = manifest()
        payload["success"] = True
        payload["portal_file"] = PORTAL_FILE
        return payload
    if endpoint == "portals":
        entries, revision = load_entries()
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise NotFoundError("Unknown EStalker API endpoint")


def web_post(endpoint, data):
    if not isinstance(data, dict):
        raise ValidationError("JSON request must be an object")
    if endpoint == "update":
        entries, revision = save_entries(data.get("entries", []), expected_revision=data.get("revision"))
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        entries, revision = restore_backup(data.get("backup"))
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    raise NotFoundError("Unknown EStalker API endpoint")
