#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""XStreamity playlists.txt adapter for MyWebUIController.

XStreamity stores one playlist URL per line in:
    /etc/enigma2/xstreamity/playlists.txt

This adapter edits that file without introducing a second web server or a
module-specific port.  The shared MyWebUIController server owns the port and
exposes this editor at /xstreamity/.
"""

from __future__ import print_function

import fcntl
import hashlib
import os
import re
import secrets
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime
from os.path import basename, dirname, exists, join, realpath
from urllib.parse import parse_qs, urlencode, urlparse

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigSelection, ConfigText, getConfigListEntry
try:
    from Components.config import ConfigPassword
except Exception:
    ConfigPassword = ConfigText
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import ControllerError, DataStoreError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, detail_skin, list_skin, load_supported_plugin_pixmap


PLUGIN_ID = "xstreamity"
PLUGIN_NAME = "XStreamity"
PLUGIN_VERSION = "1.3.0-module1-hicons2"
PLUGIN_DESCRIPTION = "Edit the XStreamity playlists.txt subscription file"
PLUGIN_WEB_PATH = "/xstreamity/"
ASYNC_WEB_ENDPOINTS = set()

PLAYLIST_FILE = "/etc/enigma2/xstreamity/playlists.txt"
BACKUP_RE = re.compile(r"^xstreamity_backup_\d{8}_\d{6}_[a-f0-9]{6}\.txt$")
ID_RE = re.compile(r"^[a-f0-9]{32}$")
MAX_ENTRIES = 1000
MAX_LINE_BYTES = 8192
TYPE_CHOICES = [("m3u_plus", "m3u_plus"), ("m3u", "m3u")]
OUTPUT_CHOICES = [("ts", "ts"), ("m3u8", "m3u8")]
LOCK = threading.RLock()


def clean_text(value, field, required=True, max_len=4096):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    if "\x00" in value or "\r" in value or "\n" in value:
        raise ValidationError("%s contains invalid characters" % field)
    return value


def validate_http_url(value, field):
    value = clean_text(value, field, required=True, max_len=MAX_LINE_BYTES)
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        raise ValidationError("%s must be a valid http:// or https:// URL" % field)
    return value


def safe_option(value, field, fallback):
    value = clean_text(value if value is not None else fallback, field, required=True, max_len=64)
    if not re.match(r"^[A-Za-z0-9_.-]+$", value):
        raise ValidationError("%s contains unsupported characters" % field)
    return value


def normalize_port(value, scheme="http"):
    if value is None or str(value).strip() == "":
        return "443" if scheme == "https" else "80"
    text = clean_text(str(value), "Port", required=True, max_len=5)
    if not text.isdigit():
        raise ValidationError("Port must be numeric")
    port = int(text)
    if port < 1 or port > 65535:
        raise ValidationError("Port must be between 1 and 65535")
    return str(port)


def _hostname_for_url(parsed):
    hostname = parsed.hostname or ""
    if ":" in hostname and not hostname.startswith("["):
        hostname = "[%s]" % hostname
    return hostname


def normalize_host(value, port_value=None):
    value = validate_http_url(value, "URL")
    parsed = urlparse(value)
    if parsed.username or parsed.password:
        raise ValidationError("URL must not include embedded credentials")
    if parsed.query or parsed.fragment:
        raise ValidationError("URL must not include a query string or fragment")
    hostname = _hostname_for_url(parsed)
    if not hostname:
        raise ValidationError("URL host is required")
    path = (parsed.path or "").rstrip("/")
    if path.lower().endswith("/get.php"):
        path = path[:-8].rstrip("/")
    try:
        parsed_port = parsed.port
    except ValueError:
        raise ValidationError("URL contains an invalid port")
    port = normalize_port(port_value if str(port_value or "").strip() else parsed_port, parsed.scheme.lower())
    host = "%s://%s%s" % (parsed.scheme.lower(), hostname, path)
    return host.rstrip("/"), port


def make_id(line, position=0):
    payload = ("%s\x00%s" % (position, line)).encode("utf-8", "replace")
    return hashlib.md5(payload).hexdigest()


def make_browser_id():
    return secrets.token_hex(16)


def parse_xtream_line(line, position=0):
    parsed = urlparse(line)
    query = parse_qs(parsed.query, keep_blank_values=True)
    path = (parsed.path or "").rstrip("/").lower()
    if not path.endswith("/get.php"):
        return None
    username = query.get("username", [""])[0]
    password = query.get("password", [""])[0]
    if not username or not password:
        return None
    host, port = normalize_host("%s://%s%s" % (
        parsed.scheme,
        parsed.netloc,
        (parsed.path or "")[:-8],
    ), parsed.port)
    return {
        "id": make_id(line, position),
        "host": host,
        "port": port,
        "username": username,
        "password": password,
        "type": query.get("type", ["m3u_plus"])[0] or "m3u_plus",
        "output": query.get("output", ["ts"])[0] or "ts",
    }


def parse_line(line, position=0):
    """Parse one XStreamity playlists.txt line as structured Xtream Code data.

    This adapter intentionally supports only Xtream get.php subscriptions.  The
    receiver and web editors therefore always expose the same six fields: URL,
    port, username, password, type option and output option.
    """
    line = validate_http_url(line, "XStreamity playlist line")
    item = parse_xtream_line(line, position=position)
    if item is None:
        raise ValidationError("Only Xtream get.php playlist lines are supported")
    return item


def _password_for_web(item, previous):
    incoming = item.get("password", "")
    if not isinstance(incoming, str):
        raise ValidationError("Password must be text")
    incoming = incoming.strip()
    if incoming:
        return clean_text(incoming, "Password", required=True, max_len=1024)
    if previous and previous.get("password"):
        return previous["password"]
    raise ValidationError("Password is required for a new Xtream entry")


def normalize_entry(item, source="stored", previous=None):
    if not isinstance(item, dict):
        raise ValidationError("Each playlist entry must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    entry_id = raw_id if ID_RE.match(raw_id) else make_browser_id()
    host, port = normalize_host(item.get("host", ""), item.get("port", ""))
    password = _password_for_web(item, previous) if source == "web" else clean_text(item.get("password", ""), "Password", required=True, max_len=1024)
    return {
        "id": entry_id,
        "host": host,
        "port": port,
        "username": clean_text(item.get("username", ""), "Username", required=True, max_len=512),
        "password": password,
        "type": safe_option(item.get("type"), "Type option", "m3u_plus"),
        "output": safe_option(item.get("output"), "Output option", "ts"),
    }


def build_line(item):
    normalized = normalize_entry(item, source="stored")
    return "%s:%s/get.php?%s" % (
        normalized["host"].rstrip("/"),
        normalized["port"],
        urlencode({
            "username": normalized["username"],
            "password": normalized["password"],
            "type": normalized["type"],
            "output": normalized["output"],
        }),
    )


def public_entry(item):
    output = dict(item)
    output.pop("password", None)
    output["password_set"] = bool(item.get("password"))
    return output


def display_name(item):
    return "Xtream: %s" % item.get("username", "Unknown")


def display_description(item):
    return "%s:%s | type=%s | output=%s" % (
        item.get("host", ""), item.get("port", ""), item.get("type", ""), item.get("output", "")
    )


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def file_lock(path, exclusive=True):
    lock_path = path + ".lock"
    folder = dirname(lock_path)
    if folder:
        os.makedirs(folder, mode=0o755, exist_ok=True)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write_bytes(path, payload, mode=0o600):
    folder = dirname(path)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".mywebui_xstreamity_", suffix=".tmp", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(folder, os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    finally:
        if exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def _encode_lines(lines):
    return (("\n".join(lines) + "\n") if lines else "").encode("utf-8")


def ensure_files():
    os.makedirs(dirname(PLAYLIST_FILE), mode=0o755, exist_ok=True)
    if not exists(PLAYLIST_FILE):
        with file_lock(PLAYLIST_FILE):
            if not exists(PLAYLIST_FILE):
                _atomic_write_bytes(PLAYLIST_FILE, b"", mode=0o600)
    try:
        os.chmod(PLAYLIST_FILE, 0o600)
    except Exception:
        pass


def _read_unlocked():
    try:
        with open(PLAYLIST_FILE, "rb") as handle:
            raw = handle.read()
    except Exception as exc:
        raise DataStoreError("Unable to read %s: %s" % (PLAYLIST_FILE, exc))
    try:
        text = raw.decode("utf-8")
    except Exception as exc:
        raise DataStoreError("Unable to decode %s as UTF-8: %s" % (PLAYLIST_FILE, exc))
    entries = []
    for line_number, raw_line in enumerate(text.splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            entries.append(parse_line(line, position=line_number - 1))
        except ValidationError as exc:
            raise DataStoreError("Unsupported XStreamity playlist line %s: %s" % (line_number, exc))
    if len(entries) > MAX_ENTRIES:
        raise DataStoreError("Too many XStreamity playlist entries")
    return entries, raw


def load_entries():
    ensure_files()
    with LOCK, file_lock(PLAYLIST_FILE, exclusive=False):
        entries, raw = _read_unlocked()
    return entries, sha256_bytes(raw)


def save_entries(items, expected_revision=None, source="tv"):
    if not isinstance(items, list):
        raise ValidationError("Playlist collection must be a list")
    if len(items) > MAX_ENTRIES:
        raise ValidationError("Too many XStreamity playlist entries")
    ensure_files()
    with LOCK, file_lock(PLAYLIST_FILE, exclusive=True):
        previous_items, raw = _read_unlocked()
        current_revision = sha256_bytes(raw)
        if expected_revision and expected_revision != current_revision:
            raise RevisionConflict("XStreamity playlists.txt changed on the receiver. Reload before saving.")
        previous_by_id = {item.get("id"): item for item in previous_items if item.get("id")}
        lines = []
        seen = set()
        for item in items:
            previous = previous_by_id.get(item.get("id")) if isinstance(item, dict) else None
            normalized = normalize_entry(item, source=source, previous=previous)
            line = build_line(normalized)
            key = line.casefold()
            if key in seen:
                raise ValidationError("Duplicate XStreamity playlist line")
            seen.add(key)
            lines.append(line)
        payload = _encode_lines(lines)
        _atomic_write_bytes(PLAYLIST_FILE, payload, mode=0o600)
    # Re-read so returned IDs reflect the persisted line positions.
    return load_entries()


def list_backups():
    folder = ensure_backup_dir()
    names = [name for name in os.listdir(folder) if BACKUP_RE.match(name)]
    names.sort(reverse=True)
    return names


def create_backup():
    ensure_files()
    entries, revision = load_entries()
    with open(PLAYLIST_FILE, "rb") as handle:
        payload = handle.read()
    filename = "xstreamity_backup_%s_%s.txt" % (datetime.now().strftime("%Y%m%d_%H%M%S"), secrets.token_hex(3))
    folder = ensure_backup_dir()
    _atomic_write_bytes(join(folder, filename), payload, mode=0o600)
    return filename


def _safe_backup_path(filename):
    filename = clean_text(filename, "Backup filename", required=True, max_len=200)
    if filename != basename(filename) or not BACKUP_RE.match(filename):
        raise ValidationError("Invalid backup filename")
    folder = realpath(ensure_backup_dir())
    candidate = realpath(join(folder, filename))
    if not candidate.startswith(folder + os.sep) or not exists(candidate):
        raise ValidationError("Backup not found")
    return candidate


def restore_backup(filename):
    source = _safe_backup_path(filename)
    with open(source, "rb") as handle:
        payload = handle.read()
    try:
        text = payload.decode("utf-8")
        for line_number, raw_line in enumerate(text.splitlines(), 1):
            line = raw_line.strip()
            if line and not line.startswith("#"):
                try:
                    parse_line(line, position=line_number - 1)
                except ValidationError as exc:
                    raise ValidationError("Unsupported XStreamity playlist line %s: %s" % (line_number, exc))
    except ControllerError:
        raise
    except Exception as exc:
        raise DataStoreError("Backup is invalid: %s" % exc)
    with LOCK, file_lock(PLAYLIST_FILE, exclusive=True):
        _atomic_write_bytes(PLAYLIST_FILE, payload, mode=0o600)
    return load_entries()


def find_entry(entry_id):
    entry_id = clean_text(entry_id, "Entry ID", required=True, max_len=32).lower()
    entries, revision = load_entries()
    for item in entries:
        if item.get("id") == entry_id:
            return item
    raise ValidationError("Playlist entry not found")


def load_plugin_pixmap():
    """Load the real XStreamity icon from images/supportedplugins."""
    return load_supported_plugin_pixmap("xtreamity.png")


class XStreamityMenuScreen(Screen):
    skin = list_skin("XStreamity Editor %s" % PLUGIN_VERSION, button_count=1, include_info=False, button_names=["Redkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        ensure_files()
        self.pixmap = load_plugin_pixmap()
        self.menu_items = [
            (_("Playlists"), _("Edit /etc/enigma2/xstreamity/playlists.txt"), "playlists"),
            (_("Backup & Restore"), _("Create or restore playlists.txt backups"), "backup"),
        ]
        self["menu"] = List([])
        self["Greenkey"] = StaticText("")
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select_item,
            "cancel": self.close,
            "red": self.close,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        self["menu"].setList([(a, b, self.pixmap, c) for a, b, c in self.menu_items])

    def select_item(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if current[3] == "playlists":
            self.session.open(PlaylistListScreen)
        elif current[3] == "backup":
            self.session.open(BackupRestoreScreen)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self.menu_items) - 1:
            self["menu"].setIndex(index + 1)


class PlaylistListScreen(Screen):
    skin = list_skin("XStreamity Playlists", button_count=3, include_info=False, button_names=["Redkey", "Greenkey", "Yellowkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.entries = []
        self.pixmap = load_plugin_pixmap()
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add"))
        self["Yellowkey"] = StaticText(_("Edit"))
        self["Redkey"] = StaticText(_("Delete"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.view_entry,
            "cancel": self.close,
            "green": self.add_entry,
            "yellow": self.edit_entry,
            "red": self.delete_entry,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_entries)

    def load_entries(self, *args):
        try:
            self.entries, revision = load_entries()
            rows = [(display_name(item), display_description(item), self.pixmap, index) for index, item in enumerate(self.entries)]
            if not rows:
                rows = [(_("No playlists found"), _("Press Add to create an Xtream Code entry"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.entries = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.entries):
            return current[3], self.entries[current[3]]
        return None, None

    def view_entry(self):
        index, item = self.selected()
        if item:
            self.session.open(EntryViewScreen, item)

    def add_entry(self):
        self.session.openWithCallback(self.load_entries, EditEntryScreen, "add")

    def edit_entry(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(self.load_entries, EditEntryScreen, "edit", item, index)

    def delete_entry(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete playlist entry?", MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            entries, revision = load_entries()
            if index >= len(entries):
                raise ValidationError("Playlist entry no longer exists")
            entries.pop(index)
            save_entries(entries, source="tv")
            self.load_entries()
            self.session.open(MessageBox, _("Playlist entry deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class EntryViewScreen(Screen):
    skin = detail_skin()

    def __init__(self, session, entry):
        Screen.__init__(self, session)
        self.entry = entry
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["DirectionActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)
        self.setTitle(display_name(entry))
        self.onLayoutFinish.append(self.display)

    def display(self):
        lines = ["=" * 60, "XSTREAMITY PLAYLIST ENTRY", "=" * 60]
        for key, value in self.entry.items():
            if key == "password":
                value = "********"
            lines.append("%-15s : %s" % (key, value))
        self["text"].setText("\n".join(lines))


class EditEntryScreen(Screen, ConfigListScreen):
    skin = config_skin("XStreamity Playlist Editor")

    def __init__(self, session, mode="add", entry=None, entry_index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.entry_index = entry_index
        self.entry = dict(entry or {})
        self.host = ConfigText(default=self.entry.get("host", "http://"), fixed_size=False)
        self.port = ConfigText(default=str(self.entry.get("port", "80")), fixed_size=False)
        self.username = ConfigText(default=self.entry.get("username", ""), fixed_size=False)
        self.password = ConfigPassword(default=self.entry.get("password", ""), fixed_size=False)
        self.playlist_type = ConfigSelection(default=self.entry.get("type", "m3u_plus"), choices=self._with_current(TYPE_CHOICES, self.entry.get("type")))
        self.output = ConfigSelection(default=self.entry.get("output", "ts"), choices=self._with_current(OUTPUT_CHOICES, self.entry.get("output")))
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add Xtream Code") if mode == "add" else _("Edit Xtream Code"))
        self.create_setup()

    @staticmethod
    def _with_current(choices, current):
        values = [item[0] for item in choices]
        if current and current not in values:
            return list(choices) + [(current, current)]
        return list(choices)

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("URL, for example http://host"), self.host),
            getConfigListEntry(_("Port"), self.port),
            getConfigListEntry(_("Username"), self.username),
            getConfigListEntry(_("Password"), self.password),
            getConfigListEntry(_("Type Option"), self.playlist_type),
            getConfigListEntry(_("Output Option"), self.output),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            if hasattr(field, "value"):
                self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                              title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def collect(self):
        return {
            "id": self.entry.get("id") or make_browser_id(),
            "host": self.host.value,
            "port": self.port.value,
            "username": self.username.value,
            "password": self.password.value,
            "type": self.playlist_type.value,
            "output": self.output.value,
        }

    def save_config(self):
        try:
            item = normalize_entry(self.collect(), source="tv")
            entries, revision = load_entries()
            if self.mode == "add":
                entries.append(item)
            else:
                if self.entry_index is None or self.entry_index >= len(entries):
                    raise ValidationError("Playlist entry no longer exists")
                entries[self.entry_index] = item
            save_entries(entries, source="tv")
            self.session.open(MessageBox, _("Playlist entry saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("XStreamity Backup & Restore", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Backup playlists.txt"), _("Create a protected backup of the XStreamity subscription file"), "backup"),
            (_("Restore playlists.txt"), _("Restore a previous XStreamity playlists.txt backup"), "restore"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        try:
            if current[3] == "backup":
                self.session.open(MessageBox, "Backup created: %s" % create_backup(), MessageBox.TYPE_INFO)
            else:
                choices = [(name, name) for name in list_backups()]
                if not choices:
                    raise ValidationError("No backups found")
                self.session.openWithCallback(self.restore_choice, ChoiceBox, title="Select backup to restore", list=choices)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def restore_choice(self, choice):
        if not choice:
            return
        try:
            restore_backup(choice[1])
            self.session.open(MessageBox, "XStreamity playlists.txt restored successfully", MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


def manifest():
    return {
        "id": PLUGIN_ID,
        "name": PLUGIN_NAME,
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(XStreamityMenuScreen)


def web_get(endpoint, args):
    if endpoint == "info":
        payload = manifest()
        payload["success"] = True
        payload["playlist_file"] = PLAYLIST_FILE
        return payload
    if endpoint == "playlists":
        entries, revision = load_entries()
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise NotFoundError("Unknown XStreamity API endpoint")


def web_post(endpoint, data):
    if not isinstance(data, dict):
        raise ValidationError("JSON request must be an object")
    if endpoint == "update":
        entries, revision = save_entries(data.get("entries", []), expected_revision=data.get("revision"), source="web")
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        entries, revision = restore_backup(data.get("backup"))
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    raise NotFoundError("Unknown XStreamity API endpoint")
