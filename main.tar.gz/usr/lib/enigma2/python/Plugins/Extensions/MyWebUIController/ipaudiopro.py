#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""IPaudioPro JSON adapter for MyWebUIController.

IPaudioPro stores grouped stream subscriptions in:
    /etc/enigma2/IPAudioPro.json

The root JSON object preserves group order.  Each group contains a ``streams``
array whose order is also preserved.  Unknown JSON keys are kept when a file is
loaded and saved, so this adapter does not discard IPaudioPro-specific fields
that may be added by future versions of the original plugin.
"""

from __future__ import print_function

import fcntl
import hashlib
import json
import os
import re
import secrets
import tempfile
import threading
from collections import OrderedDict
from contextlib import contextmanager
from datetime import datetime
from os.path import basename, dirname, exists, join, realpath
from urllib.parse import urlparse

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigText, getConfigListEntry
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import ControllerError, DataStoreError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, detail_skin, list_skin, load_supported_plugin_pixmap


PLUGIN_ID = "ipaudiopro"
PLUGIN_NAME = "IPaudioPro"
PLUGIN_VERSION = "1.0.0-module1"
PLUGIN_DESCRIPTION = "Edit grouped streams in /etc/enigma2/IPAudioPro.json"
PLUGIN_WEB_PATH = "/ipaudiopro/"
ASYNC_WEB_ENDPOINTS = set()

SOURCE_PLUGIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/IPaudioPro/"
SUBSCRIPTION_FILE = "/etc/enigma2/IPAudioPro.json"
BACKUP_RE = re.compile(r"^ipaudiopro_backup_\d{8}_\d{6}_[a-f0-9]{6}\.json$")
ID_RE = re.compile(r"^[a-f0-9]{32}$")
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_GROUPS = 1000
MAX_STREAMS_PER_GROUP = 10000
MAX_TEXT = 8192
LOCK = threading.RLock()


def clean_text(value, field, required=True, max_len=MAX_TEXT):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    if "\x00" in value or "\r" in value or "\n" in value:
        raise ValidationError("%s contains invalid characters" % field)
    return value


def validate_stream_url(value):
    value = clean_text(value, "Stream URL", required=True, max_len=MAX_TEXT)
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        raise ValidationError("Stream URL must be a valid http:// or https:// URL")
    return value


def make_id(*parts):
    payload = "\x00".join(str(part) for part in parts).encode("utf-8", "replace")
    return hashlib.md5(payload).hexdigest()


def make_browser_id():
    return secrets.token_hex(16)


def _safe_extra(value, field):
    if value is None:
        return OrderedDict()
    if not isinstance(value, dict):
        raise ValidationError("%s must be an object" % field)
    output = OrderedDict()
    for key, item in value.items():
        key = clean_text(key, "%s key" % field, required=True, max_len=256)
        if key in ("id", "name", "streams", "display_name", "url", "name_present", "extra"):
            continue
        output[key] = item
    try:
        json.dumps(output, ensure_ascii=False)
    except Exception:
        raise ValidationError("%s contains values that cannot be saved as JSON" % field)
    return output


def normalize_stream(item, position=0, group_name=""):
    if not isinstance(item, dict):
        raise ValidationError("Each IPaudioPro stream must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    display_name = clean_text(item.get("display_name", ""), "Display name", required=True, max_len=512)
    url = validate_stream_url(item.get("url", ""))
    raw_name = item.get("name", "")
    name = clean_text(raw_name, "Internal name", required=False, max_len=512)
    name_present = bool(item.get("name_present", "name" in item)) and bool(name)
    stream_id = raw_id if ID_RE.match(raw_id) else make_id(group_name, position, display_name, url, name)
    return {
        "id": stream_id,
        "display_name": display_name,
        "url": url,
        "name": name,
        "name_present": name_present,
        "extra": _safe_extra(item.get("extra"), "Stream extra fields"),
    }


def normalize_group(item, position=0):
    if not isinstance(item, dict):
        raise ValidationError("Each IPaudioPro group must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    name = clean_text(item.get("name", ""), "Group name", required=True, max_len=512)
    streams = item.get("streams", [])
    if not isinstance(streams, list):
        raise ValidationError("Streams for group %s must be a list" % name)
    if len(streams) > MAX_STREAMS_PER_GROUP:
        raise ValidationError("Too many streams in group %s" % name)
    group_id = raw_id if ID_RE.match(raw_id) else make_id(position, name)
    return {
        "id": group_id,
        "name": name,
        "streams": [normalize_stream(stream, index, name) for index, stream in enumerate(streams)],
        "extra": _safe_extra(item.get("extra"), "Group extra fields"),
    }


def normalize_groups(items):
    if not isinstance(items, list):
        raise ValidationError("IPaudioPro group collection must be a list")
    if len(items) > MAX_GROUPS:
        raise ValidationError("Too many IPaudioPro groups")
    output = []
    seen = set()
    for index, item in enumerate(items):
        group = normalize_group(item, index)
        key = group["name"].casefold()
        if key in seen:
            raise ValidationError("Duplicate IPaudioPro group name: %s" % group["name"])
        seen.add(key)
        output.append(group)
    return output


def public_stream(item):
    return {
        "id": item["id"],
        "display_name": item["display_name"],
        "url": item["url"],
        "name": item.get("name", ""),
        "name_present": bool(item.get("name_present")),
        "extra": OrderedDict(item.get("extra", {})),
    }


def public_group(item):
    return {
        "id": item["id"],
        "name": item["name"],
        "streams": [public_stream(stream) for stream in item.get("streams", [])],
        "extra": OrderedDict(item.get("extra", {})),
    }


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def file_lock(path, exclusive=True):
    lock_path = path + ".lock"
    folder = dirname(lock_path)
    if folder:
        os.makedirs(folder, mode=0o755, exist_ok=True)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write_bytes(path, payload, mode=0o600):
    folder = dirname(path)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".mywebui_ipaudiopro_", suffix=".tmp", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(folder, os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    finally:
        if exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def ensure_files():
    folder = dirname(SUBSCRIPTION_FILE)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    if not exists(SUBSCRIPTION_FILE):
        with file_lock(SUBSCRIPTION_FILE):
            if not exists(SUBSCRIPTION_FILE):
                _atomic_write_bytes(SUBSCRIPTION_FILE, b"{}\n", mode=0o600)
    try:
        os.chmod(SUBSCRIPTION_FILE, 0o600)
    except Exception:
        pass


def parse_json_payload(payload):
    if len(payload) > MAX_FILE_BYTES:
        raise DataStoreError("IPAudioPro.json is larger than %s MB" % (MAX_FILE_BYTES // (1024 * 1024)))
    try:
        decoded = json.loads(payload.decode("utf-8"), object_pairs_hook=OrderedDict)
    except Exception as exc:
        raise DataStoreError("Invalid JSON in %s: %s" % (SUBSCRIPTION_FILE, exc))
    if not isinstance(decoded, dict):
        raise DataStoreError("IPAudioPro.json root must be a JSON object")
    if len(decoded) > MAX_GROUPS:
        raise DataStoreError("Too many IPaudioPro groups")
    groups = []
    for group_index, (group_name, raw_group) in enumerate(decoded.items()):
        try:
            group_name = clean_text(group_name, "Group name", required=True, max_len=512)
        except ValidationError as exc:
            raise DataStoreError(str(exc))
        if not isinstance(raw_group, dict):
            raise DataStoreError("Group %s must be a JSON object" % group_name)
        streams = raw_group.get("streams", [])
        if not isinstance(streams, list):
            raise DataStoreError("Streams for group %s must be a JSON list" % group_name)
        group_extra = OrderedDict((key, value) for key, value in raw_group.items() if key != "streams")
        public_streams = []
        if len(streams) > MAX_STREAMS_PER_GROUP:
            raise DataStoreError("Too many streams in group %s" % group_name)
        for stream_index, raw_stream in enumerate(streams):
            if not isinstance(raw_stream, dict):
                raise DataStoreError("Stream %s in group %s must be a JSON object" % (stream_index + 1, group_name))
            try:
                display_name = clean_text(raw_stream.get("display_name", ""), "Display name", required=True, max_len=512)
                url = validate_stream_url(raw_stream.get("url", ""))
                name_present = "name" in raw_stream and bool(str(raw_stream.get("name") or "").strip())
                name = clean_text(raw_stream.get("name", ""), "Internal name", required=False, max_len=512)
            except ValidationError as exc:
                raise DataStoreError("Invalid stream %s in group %s: %s" % (stream_index + 1, group_name, exc))
            stream_extra = OrderedDict((key, value) for key, value in raw_stream.items() if key not in ("display_name", "url", "name"))
            public_streams.append({
                "id": make_id(group_index, group_name, stream_index, display_name, url, name),
                "display_name": display_name,
                "url": url,
                "name": name,
                "name_present": name_present,
                "extra": stream_extra,
            })
        groups.append({
            "id": make_id(group_index, group_name),
            "name": group_name,
            "streams": public_streams,
            "extra": group_extra,
        })
    return groups


def _encode_groups(groups):
    root = OrderedDict()
    for group in groups:
        group_obj = OrderedDict()
        for key, value in group.get("extra", {}).items():
            if key != "streams":
                group_obj[key] = value
        stream_rows = []
        for stream in group.get("streams", []):
            stream_obj = OrderedDict()
            if stream.get("name_present") and stream.get("name"):
                stream_obj["name"] = stream["name"]
            stream_obj["display_name"] = stream["display_name"]
            stream_obj["url"] = stream["url"]
            for key, value in stream.get("extra", {}).items():
                if key not in ("name", "display_name", "url"):
                    stream_obj[key] = value
            stream_rows.append(stream_obj)
        group_obj["streams"] = stream_rows
        root[group["name"]] = group_obj
    payload = (json.dumps(root, ensure_ascii=False, indent=4) + "\n").encode("utf-8")
    if len(payload) > MAX_FILE_BYTES:
        raise ValidationError("IPAudioPro.json would exceed %s MB" % (MAX_FILE_BYTES // (1024 * 1024)))
    return payload


def _read_unlocked():
    try:
        with open(SUBSCRIPTION_FILE, "rb") as handle:
            payload = handle.read(MAX_FILE_BYTES + 1)
    except Exception as exc:
        raise DataStoreError("Unable to read %s: %s" % (SUBSCRIPTION_FILE, exc))
    return parse_json_payload(payload), payload


def load_groups():
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=False):
        groups, payload = _read_unlocked()
    return groups, sha256_bytes(payload)


def save_groups(items, expected_revision=None):
    groups = normalize_groups(items)
    payload = _encode_groups(groups)
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=True):
        previous, raw = _read_unlocked()
        current_revision = sha256_bytes(raw)
        if expected_revision and expected_revision != current_revision:
            raise RevisionConflict("IPAudioPro.json changed on the receiver. Reload before saving.")
        _atomic_write_bytes(SUBSCRIPTION_FILE, payload, mode=0o600)
    return load_groups()


def list_backups():
    folder = ensure_backup_dir()
    names = [name for name in os.listdir(folder) if BACKUP_RE.match(name)]
    names.sort(reverse=True)
    return names


def create_backup():
    ensure_files()
    groups, revision = load_groups()
    with open(SUBSCRIPTION_FILE, "rb") as handle:
        payload = handle.read(MAX_FILE_BYTES + 1)
    if len(payload) > MAX_FILE_BYTES:
        raise DataStoreError("IPAudioPro.json is too large to back up")
    filename = "ipaudiopro_backup_%s_%s.json" % (datetime.now().strftime("%Y%m%d_%H%M%S"), secrets.token_hex(3))
    _atomic_write_bytes(join(ensure_backup_dir(), filename), payload, mode=0o600)
    return filename


def _safe_backup_path(filename):
    filename = clean_text(filename, "Backup filename", required=True, max_len=200)
    if filename != basename(filename) or not BACKUP_RE.match(filename):
        raise ValidationError("Invalid backup filename")
    folder = realpath(ensure_backup_dir())
    candidate = realpath(join(folder, filename))
    if not candidate.startswith(folder + os.sep) or not exists(candidate):
        raise ValidationError("Backup not found")
    return candidate


def restore_backup(filename):
    source = _safe_backup_path(filename)
    with open(source, "rb") as handle:
        payload = handle.read(MAX_FILE_BYTES + 1)
    parse_json_payload(payload)
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=True):
        _atomic_write_bytes(SUBSCRIPTION_FILE, payload, mode=0o600)
    return load_groups()


def load_plugin_pixmap():
    """Load the existing real IPaudioPro icon from images/supportedplugins."""
    return load_supported_plugin_pixmap("ipaudiopro.png")


def group_description(group):
    count = len(group.get("streams", []))
    return "%s stream%s" % (count, "" if count == 1 else "s")


def stream_description(stream):
    return stream.get("url", "")


class IPaudioProMenuScreen(Screen):
    skin = list_skin("IPaudioPro Editor %s" % PLUGIN_VERSION, button_count=1, include_info=False, button_names=["Redkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        ensure_files()
        self.pixmap = load_plugin_pixmap()
        self.menu_items = [
            (_("Groups & Streams"), _("Edit /etc/enigma2/IPAudioPro.json"), "groups"),
            (_("Backup & Restore"), _("Create or restore IPaudioPro JSON backups"), "backup"),
        ]
        self["menu"] = List([])
        self["Greenkey"] = StaticText("")
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select_item,
            "cancel": self.close,
            "red": self.close,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        self["menu"].setList([(a, b, self.pixmap, c) for a, b, c in self.menu_items])

    def select_item(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if current[3] == "groups":
            self.session.open(GroupListScreen)
        elif current[3] == "backup":
            self.session.open(BackupRestoreScreen)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self.menu_items) - 1:
            self["menu"].setIndex(index + 1)


class GroupListScreen(Screen):
    skin = list_skin("IPaudioPro Groups", button_count=4, include_info=False)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.groups = []
        self.pixmap = load_plugin_pixmap()
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add Group"))
        self["Yellowkey"] = StaticText(_("Edit Group"))
        self["Redkey"] = StaticText(_("Delete Group"))
        self["Bluekey"] = StaticText(_("Streams"))
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.open_streams,
            "cancel": self.close,
            "green": self.add_group,
            "yellow": self.edit_group,
            "red": self.delete_group,
            "blue": self.open_streams,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_groups)

    def load_groups(self, *args):
        try:
            self.groups, revision = load_groups()
            rows = [(group["name"], group_description(group), self.pixmap, index) for index, group in enumerate(self.groups)]
            if not rows:
                rows = [(_("No IPaudioPro groups found"), _("Press Add Group to create one"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.groups = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.groups):
            return current[3], self.groups[current[3]]
        return None, None

    def add_group(self):
        self.session.openWithCallback(self.load_groups, EditGroupScreen, "add")

    def edit_group(self):
        index, group = self.selected()
        if group:
            self.session.openWithCallback(self.load_groups, EditGroupScreen, "edit", group, index)

    def delete_group(self):
        index, group = self.selected()
        if group:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete group %s and its streams?" % group["name"], MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            groups, revision = load_groups()
            if index >= len(groups):
                raise ValidationError("IPaudioPro group no longer exists")
            groups.pop(index)
            save_groups(groups)
            self.load_groups()
            self.session.open(MessageBox, _("IPaudioPro group deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def open_streams(self):
        index, group = self.selected()
        if group:
            self.session.openWithCallback(self.load_groups, StreamListScreen, index)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class StreamListScreen(Screen):
    skin = list_skin("IPaudioPro Streams", button_count=3, include_info=False, button_names=["Redkey", "Greenkey", "Yellowkey"])

    def __init__(self, session, group_index):
        Screen.__init__(self, session)
        self.group_index = group_index
        self.groups = []
        self.group = None
        self.streams = []
        self.pixmap = load_plugin_pixmap()
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add Stream"))
        self["Yellowkey"] = StaticText(_("Edit Stream"))
        self["Redkey"] = StaticText(_("Delete Stream"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.view_stream,
            "cancel": self.close,
            "green": self.add_stream,
            "yellow": self.edit_stream,
            "red": self.delete_stream,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_streams)

    def load_streams(self, *args):
        try:
            self.groups, revision = load_groups()
            if self.group_index >= len(self.groups):
                raise ValidationError("IPaudioPro group no longer exists")
            self.group = self.groups[self.group_index]
            self.streams = self.group.get("streams", [])
            self.setTitle("IPaudioPro Streams - %s" % self.group["name"])
            rows = [(stream.get("display_name", "Unnamed stream"), stream_description(stream), self.pixmap, index) for index, stream in enumerate(self.streams)]
            if not rows:
                rows = [(_("No streams found"), _("Press Add Stream to create one"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.groups = []
            self.group = None
            self.streams = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.streams):
            return current[3], self.streams[current[3]]
        return None, None

    def view_stream(self):
        index, stream = self.selected()
        if stream:
            self.session.open(StreamViewScreen, stream)

    def add_stream(self):
        if self.group is not None:
            self.session.openWithCallback(self.load_streams, EditStreamScreen, self.group_index, "add")

    def edit_stream(self):
        index, stream = self.selected()
        if stream:
            self.session.openWithCallback(self.load_streams, EditStreamScreen, self.group_index, "edit", stream, index)

    def delete_stream(self):
        index, stream = self.selected()
        if stream:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete stream %s?" % stream.get("display_name", "Unknown"), MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            groups, revision = load_groups()
            if self.group_index >= len(groups):
                raise ValidationError("IPaudioPro group no longer exists")
            streams = groups[self.group_index].get("streams", [])
            if index >= len(streams):
                raise ValidationError("IPaudioPro stream no longer exists")
            streams.pop(index)
            save_groups(groups)
            self.load_streams()
            self.session.open(MessageBox, _("IPaudioPro stream deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class StreamViewScreen(Screen):
    skin = detail_skin("IPaudioPro Stream Details")

    def __init__(self, session, stream):
        Screen.__init__(self, session)
        self.stream = stream
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["DirectionActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)
        self.setTitle(stream.get("display_name", "IPaudioPro Stream"))
        self.onLayoutFinish.append(self.display)

    def display(self):
        lines = ["=" * 60, "IPAUDIOPRO STREAM DETAILS", "=" * 60]
        lines.append("%-15s : %s" % ("display_name", self.stream.get("display_name", "")))
        lines.append("%-15s : %s" % ("name", self.stream.get("name", "")))
        lines.append("%-15s : %s" % ("url", self.stream.get("url", "")))
        self["text"].setText("\n".join(lines))


class EditGroupScreen(Screen, ConfigListScreen):
    skin = config_skin("IPaudioPro Group Editor")

    def __init__(self, session, mode="add", group=None, group_index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.group_index = group_index
        self.group = dict(group or {})
        self.name = ConfigText(default=self.group.get("name", ""), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add IPaudioPro Group") if mode == "add" else _("Edit IPaudioPro Group"))
        self.create_setup()

    def create_setup(self):
        self.list = [getConfigListEntry(_("Group Name"), self.name)]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def save_config(self):
        try:
            groups, revision = load_groups()
            if self.mode == "add":
                groups.append({"id": make_browser_id(), "name": self.name.value, "streams": [], "extra": OrderedDict()})
            else:
                if self.group_index is None or self.group_index >= len(groups):
                    raise ValidationError("IPaudioPro group no longer exists")
                groups[self.group_index]["name"] = self.name.value
            save_groups(groups)
            self.session.open(MessageBox, _("IPaudioPro group saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class EditStreamScreen(Screen, ConfigListScreen):
    skin = config_skin("IPaudioPro Stream Editor")

    def __init__(self, session, group_index, mode="add", stream=None, stream_index=None):
        Screen.__init__(self, session)
        self.group_index = group_index
        self.mode = mode
        self.stream_index = stream_index
        self.stream = dict(stream or {})
        self.display_name = ConfigText(default=self.stream.get("display_name", ""), fixed_size=False)
        self.name = ConfigText(default=self.stream.get("name", ""), fixed_size=False)
        self.url = ConfigText(default=self.stream.get("url", "http://"), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add IPaudioPro Stream") if mode == "add" else _("Edit IPaudioPro Stream"))
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Display Name"), self.display_name),
            getConfigListEntry(_("Internal Name (optional)"), self.name),
            getConfigListEntry(_("Stream URL"), self.url),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def collect(self):
        name = self.name.value.strip()
        return {
            "id": self.stream.get("id") or make_browser_id(),
            "display_name": self.display_name.value,
            "name": name,
            "name_present": bool(name),
            "url": self.url.value,
            "extra": OrderedDict(self.stream.get("extra", {})),
        }

    def save_config(self):
        try:
            groups, revision = load_groups()
            if self.group_index >= len(groups):
                raise ValidationError("IPaudioPro group no longer exists")
            streams = groups[self.group_index].get("streams", [])
            stream = normalize_stream(self.collect(), len(streams), groups[self.group_index]["name"])
            if self.mode == "add":
                streams.append(stream)
            else:
                if self.stream_index is None or self.stream_index >= len(streams):
                    raise ValidationError("IPaudioPro stream no longer exists")
                streams[self.stream_index] = stream
            save_groups(groups)
            self.session.open(MessageBox, _("IPaudioPro stream saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("IPaudioPro Backup & Restore", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Backup IPAudioPro.json"), _("Create a protected backup of the grouped stream file"), "backup"),
            (_("Restore IPAudioPro.json"), _("Restore a previous IPaudioPro JSON backup"), "restore"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        try:
            if current[3] == "backup":
                self.session.open(MessageBox, "Backup created: %s" % create_backup(), MessageBox.TYPE_INFO)
            else:
                choices = [(name, name) for name in list_backups()]
                if not choices:
                    raise ValidationError("No backups found")
                self.session.openWithCallback(self.restore_choice, ChoiceBox, title="Select backup to restore", list=choices)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def restore_choice(self, choice):
        if not choice:
            return
        try:
            restore_backup(choice[1])
            self.session.open(MessageBox, "IPAudioPro.json restored successfully", MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


def manifest():
    return {
        "id": PLUGIN_ID,
        "name": PLUGIN_NAME,
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(IPaudioProMenuScreen)


def web_get(endpoint, args):
    if endpoint == "info":
        payload = manifest()
        payload["success"] = True
        payload["source_plugin_dir"] = SOURCE_PLUGIN_DIR
        payload["subscription_file"] = SUBSCRIPTION_FILE
        return payload
    if endpoint == "groups":
        groups, revision = load_groups()
        return {"success": True, "groups": [public_group(group) for group in groups], "revision": revision}
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise NotFoundError("Unknown IPaudioPro API endpoint")


def web_post(endpoint, data):
    if not isinstance(data, dict):
        raise ValidationError("JSON request must be an object")
    if endpoint == "update":
        groups, revision = save_groups(data.get("groups", []), expected_revision=data.get("revision"))
        return {"success": True, "groups": [public_group(group) for group in groups], "revision": revision}
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        groups, revision = restore_backup(data.get("backup"))
        return {"success": True, "groups": [public_group(group) for group in groups], "revision": revision}
    raise NotFoundError("Unknown IPaudioPro API endpoint")
