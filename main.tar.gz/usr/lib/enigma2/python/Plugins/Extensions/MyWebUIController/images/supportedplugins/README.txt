Place real supported plugin PNG icons here: myhybridiptv.png, xtreamity.png, estalker.png
The loader also accepts xstreamity.png as an alternative spelling.
Expected displayed size: 120x45 px.
