#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MyWebUIController for Python 3 Enigma2 images.

The controller provides one receiver entry point and one trusted-LAN web server.
Each supported receiver plugin lives in its own adapter module.  The first adapter
is myhybridiptv.py, which contains the original MyHybridIPTV editor logic.
"""

from __future__ import print_function

import json
import os
import re
import secrets
import shutil
import socket
import tarfile
import tempfile
from datetime import datetime
from os.path import dirname, exists, join
from urllib.request import Request, urlopen

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigSelection, configfile, getConfigListEntry
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
try:
    from Screens.LocationBox import LocationBox
except Exception:
    LocationBox = None
from Tools.Directories import SCOPE_PLUGINS, resolveFilename
from Tools.LoadPixmap import LoadPixmap
from twisted.internet import reactor, threads
from twisted.web import resource, server

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import ControllerError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import cfg, ensure_backup_dir, normalize_backup_dir, normalize_plugin_order, normalize_web_theme
from .ui_horizontal import config_skin, list_skin, load_supported_plugin_pixmap
from .help_screens import AboutScreen, CONTROLLER_VERSION, HelpScreen


PLUGIN_NAME = "MyWebUIController"
PLUGIN_VERSION = CONTROLLER_VERSION
PLUGIN_DESCRIPTION = "Web UI controller for subscription editors of multiple Enigma2 plugins"
PLUGIN_PATH = dirname(__file__)
WEB_PATH = join(PLUGIN_PATH, "web")
MAX_BODY_BYTES = 4 * 1024 * 1024
UPDATE_VERSION_URL = "https://raw.githubusercontent.com/popking159/mywebuicontroller/refs/heads/main/version.txt"
UPDATE_PACKAGE_URL = "https://raw.githubusercontent.com/popking159/mywebuicontroller/refs/heads/main/MyWebUIController.tar.gz"
MAX_UPDATE_VERSION_BYTES = 1024
MAX_UPDATE_PACKAGE_BYTES = 32 * 1024 * 1024
MAX_UPDATE_EXTRACTED_BYTES = 128 * 1024 * 1024
UPDATE_ARCHIVE_PREFIX = "usr/lib/enigma2/python/Plugins/Extensions/MyWebUIController/"
# Add each future adapter here.  Every adapter exposes manifest(), initialize(),
# open_main(session), web_get(endpoint, args), web_post(endpoint, data), and
# ASYNC_WEB_ENDPOINTS.
from . import bmx, estalker, ipaudioplus, ipaudiopro, ipstreamer, myhybridiptv, xstreamity

SUPPORTED_PLUGINS = (myhybridiptv, xstreamity, estalker, ipaudiopro, ipaudioplus, bmx, ipstreamer)
PLUGIN_BY_ID = {module.PLUGIN_ID: module for module in SUPPORTED_PLUGINS}


def ordered_supported_plugins():
    """Return adapters in the saved receiver-menu order.

    The fixed SUPPORTED_PLUGINS tuple remains the built-in fallback order. Any
    future adapter that is not yet present in the saved configuration is
    appended automatically.
    """
    available_ids = [module.PLUGIN_ID for module in SUPPORTED_PLUGINS]
    return tuple(PLUGIN_BY_ID[plugin_id] for plugin_id in normalize_plugin_order(available_ids))


def save_supported_plugin_order(plugin_ids):
    """Persist a safe supported-plugin order immediately."""
    available_ids = [module.PLUGIN_ID for module in SUPPORTED_PLUGINS]
    normalized = normalize_plugin_order(available_ids, value=",".join(plugin_ids))
    cfg.plugin_order.value = ",".join(normalized)
    cfg.plugin_order.save()
    configfile.save()
    return normalized

PLUGIN_ICON_FILES = {
    "myhybridiptv": "myhybridiptv.png",
    "xstreamity": "xtreamity.png",
    "estalker": "estalker.png",
    "ipaudiopro": "ipaudiopro.png",
    "ipaudioplus": "ipaudioplus.png",
    "bmx": "bmx.png",
    "ipstreamer": "ipstreamer.png",
}

WEB_PLUGIN_ICON_FILES = {
    "/images/supportedplugins/myhybridiptv.png": "images/supportedplugins/myhybridiptv.png",
    "/images/supportedplugins/xtreamity.png": "images/supportedplugins/xtreamity.png",
    "/images/supportedplugins/estalker.png": "images/supportedplugins/estalker.png",
    # IPaudioPro icon already exists in the receiver icon directory.
    # Serve that exact file directly without copying or altering it.
    "/images/supportedplugins/ipaudiopro.png": "../images/supportedplugins/ipaudiopro.png",
    # IPaudioPlus icon already exists in the receiver icon directory.
    # Serve that exact file directly without copying or altering it.
    "/images/supportedplugins/ipaudioplus.png": "../images/supportedplugins/ipaudioplus.png",
    # BouquetMakerXtream icon already exists in the receiver icon directory.
    # Serve that exact file directly without copying or altering it.
    "/images/supportedplugins/bmx.png": "../images/supportedplugins/bmx.png",
    # IPStreamer icon already exists in the receiver icon directory.
    # Serve that exact file directly without copying or altering it.
    "/images/supportedplugins/ipstreamer.png": "../images/supportedplugins/ipstreamer.png",
}


def manifest_with_web_icon(module):
    """Return an adapter manifest enriched with its browser icon URL."""
    payload = dict(module.manifest())
    filename = PLUGIN_ICON_FILES.get(payload.get("id"))
    if filename:
        payload["icon_path"] = "/images/supportedplugins/%s" % filename
    return payload



def _version_tuple(value):
    """Convert a dotted release version into a tuple suitable for comparison."""
    match = re.match(r"^\s*(?:ver\s*=\s*)?([0-9]+(?:\.[0-9]+){1,3})\s*$", str(value or ""), re.IGNORECASE)
    if not match:
        raise ValidationError("Remote version file is invalid")
    parts = [int(part) for part in match.group(1).split(".")]
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def normalize_release_version(value):
    """Return a validated dotted release version without a leading ver= prefix."""
    match = re.match(r"^\s*(?:ver\s*=\s*)?([0-9]+(?:\.[0-9]+){1,3})\s*$", str(value or ""), re.IGNORECASE)
    if not match:
        raise ValidationError("Remote version file is invalid")
    return match.group(1)


def read_url_limited(url, limit, timeout=12):
    """Download a bounded HTTPS resource used by the self-update workflow."""
    request = Request(url, headers={"User-Agent": "%s/%s" % (PLUGIN_NAME, PLUGIN_VERSION)})
    with urlopen(request, timeout=timeout) as response:
        payload = response.read(int(limit) + 1)
    if len(payload) > int(limit):
        raise ValidationError("Downloaded update resource is larger than the allowed size")
    return payload


def fetch_remote_version():
    """Download and validate the remote release number."""
    payload = read_url_limited(UPDATE_VERSION_URL, MAX_UPDATE_VERSION_BYTES, timeout=10)
    return normalize_release_version(payload.decode("utf-8", "replace"))


def remote_update_available(remote_version):
    """Return True only when the GitHub release version is newer than this build."""
    return _version_tuple(remote_version) > _version_tuple(PLUGIN_VERSION)


def _safe_archive_members(archive):
    """Validate update paths before extracting any remote archive member."""
    members = []
    extracted_bytes = 0
    for member in archive.getmembers():
        name = str(member.name or "").replace("\\", "/")
        normalized = os.path.normpath(name).replace("\\", "/")
        if normalized == UPDATE_ARCHIVE_PREFIX.rstrip("/"):
            if not member.isdir():
                raise ValidationError("Update archive has an invalid controller root entry")
            members.append((member, normalized))
            continue
        if not normalized.startswith(UPDATE_ARCHIVE_PREFIX):
            raise ValidationError("Update archive contains a file outside MyWebUIController")
        relative = normalized[len(UPDATE_ARCHIVE_PREFIX):]
        if not relative or relative.startswith("../") or relative == ".." or "/../" in relative:
            raise ValidationError("Update archive contains an unsafe path")
        if member.issym() or member.islnk() or member.isdev():
            raise ValidationError("Update archive contains an unsupported link or device entry")
        if not member.isdir() and not member.isfile():
            raise ValidationError("Update archive contains an unsupported entry")
        if member.isfile():
            extracted_bytes += int(member.size or 0)
            if extracted_bytes > MAX_UPDATE_EXTRACTED_BYTES:
                raise ValidationError("Update archive expands beyond the allowed size")
        members.append((member, normalized))
    if not members:
        raise ValidationError("Update archive is empty")
    return members


def _extract_update_archive(package_path, destination):
    """Extract validated regular files into an isolated staging folder."""
    with tarfile.open(package_path, "r:gz") as archive:
        members = _safe_archive_members(archive)
        for member, normalized in members:
            relative = normalized[len(UPDATE_ARCHIVE_PREFIX):]
            target = join(destination, relative)
            if member.isdir():
                os.makedirs(target, mode=0o755, exist_ok=True)
                continue
            os.makedirs(dirname(target), mode=0o755, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise ValidationError("Unable to extract an update file")
            with source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
            try:
                os.chmod(target, member.mode & 0o777)
            except Exception:
                pass
    if not exists(join(destination, "plugin.py")):
        raise ValidationError("Update archive does not contain plugin.py")


def _backup_current_plugin():
    """Create a rollback archive before replacing controller code."""
    backup_dir = ensure_backup_dir()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = join(backup_dir, "mywebuicontroller_before_update_%s.tar.gz" % stamp)
    with tarfile.open(path, "w:gz") as archive:
        archive.add(PLUGIN_PATH, arcname="MyWebUIController", recursive=True)
    return path


def _copy_staged_update(staged_plugin_path):
    """Overlay validated release files while preserving installed PNG artwork."""
    for root, dirs, files in os.walk(staged_plugin_path):
        dirs[:] = [name for name in dirs if name != "__pycache__"]
        relative_root = os.path.relpath(root, staged_plugin_path)
        active_root = PLUGIN_PATH if relative_root == "." else join(PLUGIN_PATH, relative_root)
        os.makedirs(active_root, mode=0o755, exist_ok=True)
        for filename in files:
            if filename.lower().endswith(".png") or filename.endswith(".pyc"):
                continue
            source = join(root, filename)
            target = join(active_root, filename)
            shutil.copy2(source, target)


def _clear_python_cache():
    """Remove stale bytecode after overlaying an update."""
    for root, dirs, files in os.walk(PLUGIN_PATH, topdown=False):
        for filename in files:
            if filename.endswith(".pyc") or filename.endswith(".pyo"):
                try:
                    os.unlink(join(root, filename))
                except Exception:
                    pass
        for dirname_value in dirs:
            if dirname_value == "__pycache__":
                shutil.rmtree(join(root, dirname_value), ignore_errors=True)


def install_remote_update(remote_version):
    """Download, validate and overlay the newer GitHub release."""
    remote_version = normalize_release_version(remote_version)
    if not remote_update_available(remote_version):
        raise ValidationError("The selected release is not newer than the installed version")
    workspace = tempfile.mkdtemp(prefix="mywebuicontroller_update_")
    package_path = join(workspace, "MyWebUIController.tar.gz")
    staged_plugin_path = join(workspace, "staged")
    try:
        payload = read_url_limited(UPDATE_PACKAGE_URL, MAX_UPDATE_PACKAGE_BYTES, timeout=30)
        with open(package_path, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.makedirs(staged_plugin_path, mode=0o755, exist_ok=True)
        _extract_update_archive(package_path, staged_plugin_path)
        rollback_path = _backup_current_plugin()
        _copy_staged_update(staged_plugin_path)
        _clear_python_cache()
        return rollback_path
    finally:
        shutil.rmtree(workspace, ignore_errors=True)

def initialize_modules():
    for module in SUPPORTED_PLUGINS:
        module.initialize()


def receiver_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        try:
            sock.close()
        except Exception:
            pass


def validate_controller_settings():
    """Validate controller-wide settings before starting or saving."""
    ensure_backup_dir()
    return True


def load_controller_pixmap():
    try:
        return LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/MyWebUIController/plugin.png"))
    except Exception:
        return None


class WebServerManager(object):
    def __init__(self):
        self.listener = None
        self.site = None
        self.session = None
        self.csrf_token = secrets.token_urlsafe(32)

    @property
    def running(self):
        return self.listener is not None

    def set_session(self, session):
        if session is not None:
            self.session = session

    def start(self, session=None, notify=False):
        self.set_session(session)
        if self.running:
            if notify:
                self.message("Web server is already running.", MessageBox.TYPE_INFO, timeout=3)
            return True
        try:
            initialize_modules()
            validate_controller_settings()
            self.csrf_token = secrets.token_urlsafe(32)
            self.site = server.Site(ControllerWebResource(self))
            self.listener = reactor.listenTCP(int(cfg.web_port.value), self.site, interface="0.0.0.0")
            if notify:
                self.message("Web server started on port %s" % cfg.web_port.value, MessageBox.TYPE_INFO, timeout=3)
            return True
        except Exception as exc:
            self.listener = None
            self.site = None
            if notify:
                self.message("Unable to start web server: %s" % exc, MessageBox.TYPE_ERROR)
            print("[%s] Unable to start web server: %s" % (PLUGIN_NAME, exc))
            return False

    def stop(self, notify=False):
        if not self.running:
            if notify:
                self.message("Web server is already stopped.", MessageBox.TYPE_INFO, timeout=3)
            return True
        try:
            listener = self.listener
            self.listener = None
            self.site = None
            listener.stopListening()
            if notify:
                self.message("Web server stopped.", MessageBox.TYPE_INFO, timeout=3)
            return True
        except Exception as exc:
            self.listener = None
            self.site = None
            if notify:
                self.message("Unable to stop web server: %s" % exc, MessageBox.TYPE_ERROR)
            print("[%s] Unable to stop web server: %s" % (PLUGIN_NAME, exc))
            return False

    def restart(self, notify=False):
        self.stop(notify=False)
        return self.start(notify=notify)

    def message(self, text, box_type, timeout=0):
        if self.session is not None:
            kwargs = {}
            if timeout:
                kwargs["timeout"] = timeout
            self.session.open(MessageBox, text, box_type, **kwargs)

    def status_text(self):
        status = "Running" if self.running else "Stopped"
        try:
            backup_dir = normalize_backup_dir()
        except Exception:
            backup_dir = "<invalid path>"
        return (
            "=== Controller Web Server ===\n"
            "Status: %s\n"
            "Auto Start: %s\n"
            "URL: http://%s:%s\n"
            "Backup Directory: %s\n"
            "Web UI Theme: %s\n"
        ) % (
            status,
            "Enabled" if cfg.web_autostart.value else "Disabled",
            receiver_ip(),
            cfg.web_port.value,
            backup_dir,
            normalize_web_theme().title(),
        )


WEB_MANAGER = WebServerManager()


class MainMenuScreen(Screen):
    skin = list_skin("MyWebUIController %s" % PLUGIN_VERSION, button_count=4, include_info=True, button_names=["Redkey", "Greenkey", "Yellowkey", "Bluekey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        WEB_MANAGER.set_session(session)
        initialize_modules()
        self.controller_pixmap = load_controller_pixmap()
        self["menu"] = List([])
        self.menu_items = []
        self.rebuild_menu_items()
        self["Greenkey"] = StaticText(_("WEB enable"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("WEB disable"))
        self["Bluekey"] = StaticText(_("Settings"))
        self["webinfo"] = Label("")
        self["actions"] = ActionMap(
            ["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "InfobarEPGActions", "HelpActions", "ChannelSelectBaseActions", "InfobarChannelSelection"],
            {
                "info": self.open_about,
                "displayHelp": self.open_help,
                "ok": self.select_item,
                "cancel": self.close,
                "red": self.disable_web,
                "green": self.enable_web,
                "yellow": self.empty_yellow,
                "blue": self.open_settings,
                "up": self.page_up,
                "down": self.page_down,
                # Different Enigma2 images map the physical CH+/CH- keys to
                # different action names. Support the common variants so the
                # selected adapter can be moved reliably on receiver remotes.
                "nextBouquet": self.move_plugin_up,
                "prevBouquet": self.move_plugin_down,
                "channelUp": self.move_plugin_up,
                "channelDown": self.move_plugin_down,
                "pageUp": self.move_plugin_up,
                "pageDown": self.move_plugin_down,
            },
            -1,
        )
        self.onLayoutFinish.append(self.refresh)

    def selected_plugin_id(self):
        current = self["menu"].getCurrent()
        if current and current[3] and current[3][0] == "plugin":
            return current[3][1]
        return None

    def rebuild_menu_items(self, preferred_plugin_id=None):
        """Rebuild the receiver list and preserve the selected adapter."""
        self.menu_items = []
        for module in ordered_supported_plugins():
            manifest = module.manifest()
            pixmap = load_supported_plugin_pixmap(PLUGIN_ICON_FILES[manifest["id"]])
            self.menu_items.append((_(manifest["name"]), _(manifest["description"]), pixmap, ("plugin", manifest["id"])))
        self["menu"].setList(self.menu_items)
        if preferred_plugin_id:
            for index, row in enumerate(self.menu_items):
                if row[3][1] == preferred_plugin_id:
                    self["menu"].setIndex(index)
                    break

    def refresh(self):
        self.rebuild_menu_items(self.selected_plugin_id())
        self["webinfo"].setText(WEB_MANAGER.status_text())

    def select_item(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        action, plugin_id = current[3]
        if action == "plugin":
            module = PLUGIN_BY_ID.get(plugin_id)
            if module is not None:
                module.open_main(self.session)

    def open_about(self):
        self.session.open(AboutScreen)

    def open_help(self):
        self.session.open(HelpScreen)

    def open_settings(self):
        self.session.openWithCallback(self.settings_closed, WebConfigScreen)

    def empty_yellow(self):
        """Reserved for a future main-screen action."""
        pass

    def settings_closed(self, result):
        # Saving controller settings must never start, stop, or restart the
        # shared web server.  The main-screen RED and GREEN buttons are the
        # only manual controls for the running listener.  When a saved port
        # change should become active immediately, disable and enable the web
        # server explicitly from the main screen.
        self.refresh()

    def enable_web(self):
        WEB_MANAGER.start(session=self.session, notify=True)
        self.refresh()

    def disable_web(self):
        WEB_MANAGER.stop(notify=True)
        self.refresh()

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self.menu_items) - 1:
            self["menu"].setIndex(index + 1)

    def move_plugin_up(self):
        self.move_selected_plugin(-1)

    def move_plugin_down(self):
        self.move_selected_plugin(1)

    def move_selected_plugin(self, offset):
        """Move the highlighted adapter and save its new position immediately."""
        if not cfg.allow_plugin_reorder.value:
            self.session.open(
                MessageBox,
                _("Plugin list rearrangement is disabled. Enable it from Settings."),
                MessageBox.TYPE_INFO,
                timeout=3,
            )
            return
        current = self["menu"].getCurrent()
        if not current:
            return
        index = self["menu"].getIndex()
        target = index + int(offset)
        if target < 0 or target >= len(self.menu_items):
            return
        selected_id = current[3][1]
        plugin_ids = [row[3][1] for row in self.menu_items]
        plugin_ids[index], plugin_ids[target] = plugin_ids[target], plugin_ids[index]
        save_supported_plugin_order(plugin_ids)
        self.rebuild_menu_items(selected_id)


class WebConfigScreen(ConfigListScreen, Screen):
    skin = config_skin("MyWebUIController Settings", button_names=["Redkey", "Greenkey", "Yellowkey", "Bluekey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self["Redkey"] = StaticText(_("Cancel"))
        self["Greenkey"] = StaticText(_("Save"))
        self["Yellowkey"] = StaticText(_("Select folder"))
        self["Bluekey"] = StaticText("")
        self.rows = []
        self.update_action = ConfigSelection(default="check", choices=[("check", "Press OK to check")])
        self.update_in_progress = False
        ConfigListScreen.__init__(self, self.rows, session=session)
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.cancel,
            "green": self.save,
            "yellow": self.select_backup_directory,
            "blue": self.empty_blue,
            "ok": self.ok_pressed,
            "cancel": self.cancel,
        }, -1)
        self.create_setup()

    def empty_blue(self):
        """Reserved for a future settings-screen action."""
        pass

    def create_setup(self):
        self.rows = [
            getConfigListEntry(_("Web Interface Port"), cfg.web_port),
            getConfigListEntry(_("Start Web Server Automatically"), cfg.web_autostart),
            getConfigListEntry(_("Backup Directory"), cfg.backup_dir),
            getConfigListEntry(_("Web UI Theme"), cfg.web_theme),
            getConfigListEntry(_("Enable Plugin List Rearrangement"), cfg.allow_plugin_reorder),
            getConfigListEntry(_("Check for Updates"), self.update_action),
        ]
        self["config"].setList(self.rows)

    def ok_pressed(self):
        current = self["config"].getCurrent()
        if current and current[1] is self.update_action:
            self.check_for_updates()
            return
        self.save()

    def check_for_updates(self):
        if self.update_in_progress:
            return
        self.update_in_progress = True
        self.session.open(MessageBox, _("Checking for updates..."), MessageBox.TYPE_INFO, timeout=2)
        reactor.callInThread(self._check_for_updates_worker)

    def _check_for_updates_worker(self):
        try:
            remote_version = fetch_remote_version()
            reactor.callFromThread(self._remote_version_ready, remote_version)
        except Exception as exc:
            reactor.callFromThread(self._update_failed, "Unable to check for updates: %s" % exc)

    def _remote_version_ready(self, remote_version):
        self.update_in_progress = False
        if not remote_update_available(remote_version):
            self.session.open(
                MessageBox,
                _("You already have the latest version: %s") % PLUGIN_VERSION,
                MessageBox.TYPE_INFO,
                timeout=4,
            )
            return
        self.session.openWithCallback(
            lambda answer: self.confirm_update(answer, remote_version),
            MessageBox,
            _("A newer MyWebUIController version is available.\n\nInstalled: %s\nAvailable: %s\n\nDownload and install it now?") % (PLUGIN_VERSION, remote_version),
            MessageBox.TYPE_YESNO,
        )

    def confirm_update(self, answer, remote_version):
        if not answer or self.update_in_progress:
            return
        self.update_in_progress = True
        self.session.open(MessageBox, _("Downloading and installing the update..."), MessageBox.TYPE_INFO, timeout=3)
        reactor.callInThread(self._install_update_worker, remote_version)

    def _install_update_worker(self, remote_version):
        try:
            rollback_path = install_remote_update(remote_version)
            reactor.callFromThread(self._update_installed, remote_version, rollback_path)
        except Exception as exc:
            reactor.callFromThread(self._update_failed, "Unable to install update: %s" % exc)

    def _update_installed(self, remote_version, rollback_path):
        self.update_in_progress = False
        self.session.open(
            MessageBox,
            _("MyWebUIController %s was installed successfully.\n\nRestart Enigma2 to activate the new version.\n\nRollback backup:\n%s") % (remote_version, rollback_path),
            MessageBox.TYPE_INFO,
        )

    def _update_failed(self, message):
        self.update_in_progress = False
        self.session.open(MessageBox, _(message), MessageBox.TYPE_ERROR)

    def select_backup_directory(self):
        """Open a folder picker when supported, with keyboard fallback."""
        current = cfg.backup_dir.value or "/etc/enigma2/mywebuicontroller_backups/"
        if LocationBox is not None:
            try:
                self.session.openWithCallback(
                    self.backup_directory_selected,
                    LocationBox,
                    text=_("Select the shared backup directory"),
                    currDir=current,
                    minFree=0,
                    autoAdd=True,
                    editDir=True,
                )
                return
            except Exception:
                pass
        self.session.openWithCallback(
            self.backup_directory_selected,
            VirtualKeyBoard,
            title=_("Enter shared backup directory"),
            text=current,
        )

    def backup_directory_selected(self, selected):
        if not selected:
            return
        if isinstance(selected, (tuple, list)):
            selected = selected[0] if selected else ""
        selected = str(selected).strip()
        if selected:
            cfg.backup_dir.value = selected
            self["config"].invalidateCurrent()

    def save(self):
        try:
            for row in self["config"].list:
                if row[1] is not self.update_action:
                    row[1].save()
            validate_controller_settings()
            configfile.save()
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def cancel(self):
        for row in self["config"].list:
            if row[1] is not self.update_action:
                row[1].cancel()
        self.close(False)


class ControllerWebResource(resource.Resource):
    isLeaf = True

    def __init__(self, manager):
        resource.Resource.__init__(self)
        self.manager = manager

    def security_headers(self, request):
        request.setHeader("X-Content-Type-Options", "nosniff")
        request.setHeader("X-Frame-Options", "DENY")
        request.setHeader("Referrer-Policy", "no-referrer")
        request.setHeader("Cache-Control", "no-store")
        request.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'")

    def json_response(self, request, payload, status=200):
        request.setResponseCode(status)
        request.setHeader("Content-Type", "application/json; charset=utf-8")
        return json.dumps(payload, ensure_ascii=False).encode("utf-8")

    def require_csrf(self, request):
        received = request.getHeader("x-csrf-token") or ""
        return secrets.compare_digest(received, self.manager.csrf_token)

    def body_json(self, request):
        content_length = request.getHeader("content-length")
        if content_length:
            try:
                if int(content_length) > MAX_BODY_BYTES:
                    raise ValidationError("Request body is too large")
            except ValueError:
                raise ValidationError("Invalid Content-Length")
        raw = request.content.read(MAX_BODY_BYTES + 1)
        if len(raw) > MAX_BODY_BYTES:
            raise ValidationError("Request body is too large")
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            raise ValidationError("Invalid JSON request")
        if not isinstance(data, dict):
            raise ValidationError("JSON request must be an object")
        return data

    def serve_web_file(self, filename):
        path = join(WEB_PATH, filename)
        if not exists(path):
            raise NotFoundError("Web file not found")
        with open(path, "rb") as handle:
            return handle.read()

    def parse_plugin_api(self, path):
        prefix = "/api/plugins/"
        if not path.startswith(prefix):
            raise NotFoundError("Not found")
        pieces = path[len(prefix):].strip("/").split("/", 1)
        if len(pieces) != 2 or not pieces[0] or not pieces[1]:
            raise NotFoundError("Not found")
        module = PLUGIN_BY_ID.get(pieces[0])
        if module is None:
            raise NotFoundError("Unsupported plugin")
        return module, pieces[1]

    def status_for_error(self, error):
        if isinstance(error, RevisionConflict):
            return 409
        if isinstance(error, NotFoundError):
            return 404
        if isinstance(error, ControllerError):
            return 400
        return 500

    def error_response(self, request, error):
        return self.json_response(request, {"success": False, "error": str(error)}, status=self.status_for_error(error))

    def render_GET(self, request):
        self.security_headers(request)
        path = request.path.decode("utf-8", "replace")
        try:
            static_files = {
                "/": ("index.html", "text/html; charset=utf-8"),
                "/style.css": ("style.css", "text/css; charset=utf-8"),
                "/script.js": ("script.js", "application/javascript; charset=utf-8"),
                "/theme.js": ("theme.js", "application/javascript; charset=utf-8"),
                "/plugin.png": ("plugin.png", "image/png"),
                "/myhybridiptv/": ("myhybridiptv.html", "text/html; charset=utf-8"),
                "/myhybridiptv.js": ("myhybridiptv.js", "application/javascript; charset=utf-8"),
                "/myhybridiptv/myhybridiptv.js": ("myhybridiptv.js", "application/javascript; charset=utf-8"),
                "/xstreamity/": ("xstreamity.html", "text/html; charset=utf-8"),
                "/xstreamity.js": ("xstreamity.js", "application/javascript; charset=utf-8"),
                "/xstreamity/xstreamity.js": ("xstreamity.js", "application/javascript; charset=utf-8"),
                "/estalker/": ("estalker.html", "text/html; charset=utf-8"),
                "/estalker.js": ("estalker.js", "application/javascript; charset=utf-8"),
                "/estalker/estalker.js": ("estalker.js", "application/javascript; charset=utf-8"),
                "/ipaudiopro/": ("ipaudiopro.html", "text/html; charset=utf-8"),
                "/ipaudiopro.js": ("ipaudiopro.js", "application/javascript; charset=utf-8"),
                "/ipaudiopro/ipaudiopro.js": ("ipaudiopro.js", "application/javascript; charset=utf-8"),
                "/ipaudioplus/": ("ipaudioplus.html", "text/html; charset=utf-8"),
                "/ipaudioplus.js": ("ipaudioplus.js", "application/javascript; charset=utf-8"),
                "/ipaudioplus/ipaudioplus.js": ("ipaudioplus.js", "application/javascript; charset=utf-8"),
                "/bouquetmakerxtream/": ("bmx.html", "text/html; charset=utf-8"),
                "/bmx/": ("bmx.html", "text/html; charset=utf-8"),
                "/bmx.js": ("bmx.js", "application/javascript; charset=utf-8"),
                "/bouquetmakerxtream/bmx.js": ("bmx.js", "application/javascript; charset=utf-8"),
                "/bmx/bmx.js": ("bmx.js", "application/javascript; charset=utf-8"),
                "/ipstreamer/": ("ipstreamer.html", "text/html; charset=utf-8"),
                "/ipstreamer.js": ("ipstreamer.js", "application/javascript; charset=utf-8"),
                "/ipstreamer/ipstreamer.js": ("ipstreamer.js", "application/javascript; charset=utf-8"),
            }
            for icon_url, icon_file in WEB_PLUGIN_ICON_FILES.items():
                static_files[icon_url] = (icon_file, "image/png")
            redirects = {
                "/myhybridiptv": "/myhybridiptv/",
                "/xstreamity": "/xstreamity/",
                "/estalker": "/estalker/",
                "/ipaudiopro": "/ipaudiopro/",
                "/ipaudioplus": "/ipaudioplus/",
                "/bouquetmakerxtream": "/bouquetmakerxtream/",
                "/bmx": "/bmx/",
                "/ipstreamer": "/ipstreamer/",
            }
            if path in redirects:
                request.redirect(redirects[path].encode("utf-8"))
                return b""
            if path in static_files:
                filename, content_type = static_files[path]
                request.setHeader("Content-Type", content_type)
                return self.serve_web_file(filename)
            if path == "/api/session":
                return self.json_response(request, {
                    "success": True,
                    "csrf": self.manager.csrf_token,
                    "version": PLUGIN_VERSION,
                    "backup_directory": normalize_backup_dir(),
                    "theme": normalize_web_theme(),
                })
            if path == "/api/plugins":
                return self.json_response(request, {"success": True, "plugins": [manifest_with_web_icon(module) for module in ordered_supported_plugins()]})
            if path == "/api/theme":
                return self.json_response(request, {"success": True, "theme": normalize_web_theme()})
            module, endpoint = self.parse_plugin_api(path)
            return self.json_response(request, module.web_get(endpoint, request.args))
        except Exception as exc:
            return self.error_response(request, exc)

    def render_POST(self, request):
        self.security_headers(request)
        if not self.require_csrf(request):
            return self.json_response(request, {"success": False, "error": "Invalid CSRF token"}, status=403)
        path = request.path.decode("utf-8", "replace")
        try:
            if path == "/api/theme":
                data = self.body_json(request)
                cfg.web_theme.value = normalize_web_theme(data.get("theme"))
                cfg.web_theme.save()
                configfile.save()
                return self.json_response(request, {"success": True, "theme": normalize_web_theme()})
            module, endpoint = self.parse_plugin_api(path)
            data = self.body_json(request)
            if endpoint in getattr(module, "ASYNC_WEB_ENDPOINTS", set()):
                return self.async_response(request, lambda: module.web_post(endpoint, data))
            return self.json_response(request, module.web_post(endpoint, data))
        except Exception as exc:
            return self.error_response(request, exc)

    def async_response(self, request, worker):
        deferred = threads.deferToThread(worker)

        def done(payload):
            if not request.finished:
                request.write(self.json_response(request, payload, status=200))
                request.finish()

        def failed(failure):
            if not request.finished:
                error = getattr(failure, "value", failure)
                request.write(self.error_response(request, error))
                request.finish()

        deferred.addCallbacks(done, failed)
        return server.NOT_DONE_YET


def main(session, **kwargs):
    WEB_MANAGER.set_session(session)
    session.open(MainMenuScreen)


def session_start(reason, **kwargs):
    if reason == 0:
        session = kwargs.get("session")
        WEB_MANAGER.set_session(session)
        try:
            initialize_modules()
        except Exception as exc:
            print("[%s] Module initialization failed: %s" % (PLUGIN_NAME, exc))
        if cfg.web_autostart.value:
            WEB_MANAGER.start(session=session, notify=False)


def autostart(reason, **kwargs):
    if reason == 1:
        WEB_MANAGER.stop(notify=False)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESCRIPTION,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png",
        ),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=session_start),
        PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart),
    ]
