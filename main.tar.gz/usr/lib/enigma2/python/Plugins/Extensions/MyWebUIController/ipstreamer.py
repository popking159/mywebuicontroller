#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""IPStreamer ipstreamer_extra.json adapter for MyWebUIController.

IPStreamer stores an editable playlist in:
    /etc/enigma2/ipstreamer/ipstreamer_extra.json

Expected JSON shape:
    {"playlist": [{"channel": "Name", "url": "http://..."}]}

The adapter preserves unknown root and playlist-entry fields so a future
IPStreamer release can extend the schema without losing unrelated data.
"""

from __future__ import print_function

import fcntl
import hashlib
import json
import os
import re
import secrets
import tempfile
import threading
from collections import OrderedDict
from contextlib import contextmanager
from datetime import datetime
from os.path import basename, dirname, exists, join, realpath
from urllib.parse import urlparse

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigText, getConfigListEntry
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import DataStoreError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, detail_skin, list_skin, load_supported_plugin_pixmap


PLUGIN_ID = "ipstreamer"
PLUGIN_NAME = "IPStreamer"
PLUGIN_VERSION = "1.0.0-module1"
PLUGIN_DESCRIPTION = "Edit the IPStreamer ipstreamer_extra.json subscription file"
PLUGIN_WEB_PATH = "/ipstreamer/"
ASYNC_WEB_ENDPOINTS = set()

SUBSCRIPTION_FILE = "/etc/enigma2/ipstreamer/ipstreamer_extra.json"
BACKUP_RE = re.compile(r"^ipstreamer_backup_\d{8}_\d{6}_[a-f0-9]{6}\.json$")
ID_RE = re.compile(r"^[a-f0-9]{32}$")
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_ENTRIES = 5000
MAX_TEXT = 8192
LOCK = threading.RLock()


def clean_text(value, field, required=True, max_len=MAX_TEXT):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    if "\x00" in value or "\r" in value or "\n" in value:
        raise ValidationError("%s contains invalid characters" % field)
    return value


def validate_stream_url(value):
    value = clean_text(value, "Stream URL", required=True, max_len=MAX_TEXT)
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        raise ValidationError("Stream URL must be a valid http:// or https:// URL")
    return value


def make_id(position, channel, url):
    payload = ("%s\x00%s\x00%s" % (position, channel, url)).encode("utf-8", "replace")
    return hashlib.md5(payload).hexdigest()


def make_browser_id():
    return secrets.token_hex(16)


def _safe_extra(value, field):
    if value is None:
        return OrderedDict()
    if not isinstance(value, dict):
        raise ValidationError("%s must be an object" % field)
    output = OrderedDict()
    for key, item in value.items():
        key = clean_text(key, "%s key" % field, required=True, max_len=256)
        if key in ("id", "channel", "url", "extra"):
            continue
        output[key] = item
    try:
        json.dumps(output, ensure_ascii=False)
    except Exception:
        raise ValidationError("%s contains values that cannot be saved as JSON" % field)
    return output


def normalize_entry(item, position=0):
    if not isinstance(item, dict):
        raise ValidationError("Each IPStreamer playlist entry must be an object")
    raw_id = str(item.get("id") or "").strip().lower()
    channel = clean_text(item.get("channel", ""), "Channel name", required=True, max_len=512)
    url = validate_stream_url(item.get("url", ""))
    entry_id = raw_id if ID_RE.match(raw_id) else make_id(position, channel, url)
    return {
        "id": entry_id,
        "channel": channel,
        "url": url,
        "extra": _safe_extra(item.get("extra"), "Entry extra fields"),
    }


def public_entry(item):
    return {
        "id": item["id"],
        "channel": item["channel"],
        "url": item["url"],
        "extra": OrderedDict(item.get("extra", {})),
    }


def display_name(item):
    return item.get("channel", "Unknown")


def display_description(item):
    return item.get("url", "")


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def file_lock(path, exclusive=True):
    lock_path = path + ".lock"
    folder = dirname(lock_path)
    if folder:
        os.makedirs(folder, mode=0o755, exist_ok=True)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write_bytes(path, payload, mode=0o600):
    folder = dirname(path)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".mywebui_ipstreamer_", suffix=".tmp", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(folder, os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    finally:
        if exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def ensure_files():
    os.makedirs(dirname(SUBSCRIPTION_FILE), mode=0o755, exist_ok=True)
    if not exists(SUBSCRIPTION_FILE):
        with file_lock(SUBSCRIPTION_FILE):
            if not exists(SUBSCRIPTION_FILE):
                _atomic_write_bytes(SUBSCRIPTION_FILE, b'{\n    "playlist": []\n}\n', mode=0o600)
    try:
        os.chmod(SUBSCRIPTION_FILE, 0o600)
    except Exception:
        pass


def _entry_from_raw(raw_item, position):
    if not isinstance(raw_item, dict):
        raise DataStoreError("Each IPStreamer playlist entry must be a JSON object")
    try:
        channel = clean_text(raw_item.get("channel", ""), "Channel name", required=True, max_len=512)
        url = validate_stream_url(raw_item.get("url", ""))
    except ValidationError as exc:
        raise DataStoreError(str(exc))
    extra = OrderedDict((key, value) for key, value in raw_item.items() if key not in ("channel", "url"))
    return {
        "id": make_id(position, channel, url),
        "channel": channel,
        "url": url,
        "extra": extra,
    }


def parse_json_payload(payload):
    if len(payload) > MAX_FILE_BYTES:
        raise DataStoreError("ipstreamer_extra.json is larger than %s MB" % (MAX_FILE_BYTES // (1024 * 1024)))
    try:
        decoded = json.loads(payload.decode("utf-8"), object_pairs_hook=OrderedDict)
    except Exception as exc:
        raise DataStoreError("Invalid JSON in %s: %s" % (SUBSCRIPTION_FILE, exc))
    if not isinstance(decoded, dict):
        raise DataStoreError("ipstreamer_extra.json root must be a JSON object")
    playlist = decoded.get("playlist", [])
    if not isinstance(playlist, list):
        raise DataStoreError("IPStreamer playlist must be a JSON list")
    if len(playlist) > MAX_ENTRIES:
        raise DataStoreError("Too many IPStreamer playlist entries")
    entries = [_entry_from_raw(item, index) for index, item in enumerate(playlist)]
    root_extra = OrderedDict((key, value) for key, value in decoded.items() if key != "playlist")
    return entries, root_extra


def _encode_entries(items, root_extra=None):
    root = OrderedDict()
    root["playlist"] = []
    for item in items:
        raw = OrderedDict()
        raw["channel"] = item["channel"]
        raw["url"] = item["url"]
        for key, value in OrderedDict(item.get("extra", {})).items():
            if key not in ("id", "channel", "url", "extra"):
                raw[key] = value
        root["playlist"].append(raw)
    for key, value in OrderedDict(root_extra or {}).items():
        if key != "playlist":
            root[key] = value
    return (json.dumps(root, ensure_ascii=False, indent=4) + "\n").encode("utf-8")


def _read_unlocked():
    try:
        with open(SUBSCRIPTION_FILE, "rb") as handle:
            raw = handle.read()
    except Exception as exc:
        raise DataStoreError("Unable to read %s: %s" % (SUBSCRIPTION_FILE, exc))
    entries, root_extra = parse_json_payload(raw)
    return entries, root_extra, raw


def load_entries():
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=False):
        entries, root_extra, raw = _read_unlocked()
    return entries, sha256_bytes(raw)


def save_entries(items, expected_revision=None):
    if not isinstance(items, list):
        raise ValidationError("IPStreamer playlist collection must be a list")
    if len(items) > MAX_ENTRIES:
        raise ValidationError("Too many IPStreamer playlist entries")
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=True):
        previous, root_extra, raw = _read_unlocked()
        current_revision = sha256_bytes(raw)
        if expected_revision and expected_revision != current_revision:
            raise RevisionConflict("IPStreamer ipstreamer_extra.json changed on the receiver. Reload before saving.")
        normalized = []
        seen = set()
        for position, item in enumerate(items):
            entry = normalize_entry(item, position)
            key = (entry["channel"].casefold(), entry["url"])
            if key in seen:
                raise ValidationError("Duplicate IPStreamer channel and URL pair")
            seen.add(key)
            normalized.append(entry)
        _atomic_write_bytes(SUBSCRIPTION_FILE, _encode_entries(normalized, root_extra), mode=0o600)
    return load_entries()


def list_backups():
    folder = ensure_backup_dir()
    names = [name for name in os.listdir(folder) if BACKUP_RE.match(name)]
    names.sort(reverse=True)
    return names


def create_backup():
    ensure_files()
    with open(SUBSCRIPTION_FILE, "rb") as handle:
        payload = handle.read()
    filename = "ipstreamer_backup_%s_%s.json" % (datetime.now().strftime("%Y%m%d_%H%M%S"), secrets.token_hex(3))
    _atomic_write_bytes(join(ensure_backup_dir(), filename), payload, mode=0o600)
    return filename


def _safe_backup_path(filename):
    filename = clean_text(filename, "Backup filename", required=True, max_len=200)
    if filename != basename(filename) or not BACKUP_RE.match(filename):
        raise ValidationError("Invalid backup filename")
    folder = realpath(ensure_backup_dir())
    candidate = realpath(join(folder, filename))
    if not candidate.startswith(folder + os.sep):
        raise ValidationError("Invalid backup path")
    if not exists(candidate):
        raise ValidationError("Backup not found")
    return candidate


def restore_backup(filename):
    source = _safe_backup_path(filename)
    try:
        with open(source, "rb") as handle:
            payload = handle.read()
        parse_json_payload(payload)
    except DataStoreError:
        raise
    except Exception as exc:
        raise DataStoreError("Backup is invalid: %s" % exc)
    ensure_files()
    with LOCK, file_lock(SUBSCRIPTION_FILE, exclusive=True):
        _atomic_write_bytes(SUBSCRIPTION_FILE, payload, mode=0o600)
    return load_entries()


def load_plugin_pixmap():
    return load_supported_plugin_pixmap("ipstreamer.png")


class IPStreamerMenuScreen(Screen):
    skin = list_skin("IPStreamer Editor", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Playlist Entries"), _("Manage IPStreamer channel names and stream URLs"), "entries"),
            (_("Backup & Restore"), _("Create or restore a backup of ipstreamer_extra.json"), "backup"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if current[3] == "entries":
            self.session.open(PlaylistListScreen)
        elif current[3] == "backup":
            self.session.open(BackupRestoreScreen)


class PlaylistListScreen(Screen):
    skin = list_skin("IPStreamer Playlist", button_count=3, include_info=False, button_names=["Redkey", "Greenkey", "Yellowkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.entries = []
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add"))
        self["Yellowkey"] = StaticText(_("Edit"))
        self["Redkey"] = StaticText(_("Delete"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.view_entry,
            "cancel": self.close,
            "green": self.add_entry,
            "yellow": self.edit_entry,
            "red": self.delete_entry,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_entries)

    def load_entries(self, *args):
        try:
            self.entries, revision = load_entries()
            rows = [(display_name(item), display_description(item), self.pixmap, index) for index, item in enumerate(self.entries)]
            if not rows:
                rows = [(_("No IPStreamer entries found"), _("Press Add to create a channel record"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.entries = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.entries):
            return current[3], self.entries[current[3]]
        return None, None

    def view_entry(self):
        index, item = self.selected()
        if item:
            self.session.open(EntryViewScreen, item)

    def add_entry(self):
        self.session.openWithCallback(self.load_entries, EditEntryScreen, "add")

    def edit_entry(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(self.load_entries, EditEntryScreen, "edit", item, index)

    def delete_entry(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete IPStreamer channel: %s?" % item["channel"], MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            entries, revision = load_entries()
            if index >= len(entries):
                raise ValidationError("IPStreamer entry no longer exists")
            entries.pop(index)
            save_entries(entries)
            self.load_entries()
            self.session.open(MessageBox, _("IPStreamer entry deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class EntryViewScreen(Screen):
    skin = detail_skin("IPStreamer Entry Details")

    def __init__(self, session, entry):
        Screen.__init__(self, session)
        self.entry = entry
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["DirectionActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)
        self.setTitle(display_name(entry))
        self.onLayoutFinish.append(self.display)

    def display(self):
        lines = ["=" * 60, "IPSTREAMER ENTRY DETAILS", "=" * 60]
        for key, value in self.entry.items():
            lines.append("%-15s : %s" % (key, value))
        self["text"].setText("\n".join(lines))


class EditEntryScreen(Screen, ConfigListScreen):
    skin = config_skin("IPStreamer Entry Editor")

    def __init__(self, session, mode="add", entry=None, entry_index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.entry_index = entry_index
        self.entry = dict(entry or {})
        self.channel = ConfigText(default=self.entry.get("channel", ""), fixed_size=False)
        self.url = ConfigText(default=self.entry.get("url", "http://"), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add IPStreamer Entry") if mode == "add" else _("Edit IPStreamer Entry"))
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Channel Name"), self.channel),
            getConfigListEntry(_("Stream URL"), self.url),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=str(field.value))

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def collect(self):
        return {
            "id": self.entry.get("id") or make_browser_id(),
            "channel": self.channel.value,
            "url": self.url.value,
            "extra": OrderedDict(self.entry.get("extra", {})),
        }

    def save_config(self):
        try:
            item = normalize_entry(self.collect(), self.entry_index or 0)
            entries, revision = load_entries()
            if self.mode == "add":
                entries.append(item)
            else:
                if self.entry_index is None or self.entry_index >= len(entries):
                    raise ValidationError("IPStreamer entry no longer exists")
                entries[self.entry_index] = item
            save_entries(entries)
            self.session.open(MessageBox, _("IPStreamer entry saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("IPStreamer Backup & Restore", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Backup ipstreamer_extra.json"), _("Create a protected backup of the IPStreamer playlist file"), "backup"),
            (_("Restore ipstreamer_extra.json"), _("Restore a previous IPStreamer playlist backup"), "restore"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        try:
            if current[3] == "backup":
                self.session.open(MessageBox, "Backup created: %s" % create_backup(), MessageBox.TYPE_INFO)
            else:
                choices = [(name, name) for name in list_backups()]
                if not choices:
                    raise ValidationError("No backups found")
                self.session.openWithCallback(self.restore_choice, ChoiceBox, title="Select backup to restore", list=choices)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def restore_choice(self, choice):
        if not choice:
            return
        try:
            restore_backup(choice[1])
            self.session.open(MessageBox, "IPStreamer ipstreamer_extra.json restored successfully", MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


def manifest():
    return {
        "id": PLUGIN_ID,
        "name": PLUGIN_NAME,
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(IPStreamerMenuScreen)


def web_get(endpoint, args):
    if endpoint == "info":
        payload = manifest()
        payload["success"] = True
        payload["subscription_file"] = SUBSCRIPTION_FILE
        return payload
    if endpoint == "playlist":
        entries, revision = load_entries()
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise NotFoundError("Unknown IPStreamer API endpoint")


def web_post(endpoint, data):
    if not isinstance(data, dict):
        raise ValidationError("JSON request must be an object")
    if endpoint == "update":
        entries, revision = save_entries(data.get("entries", []), expected_revision=data.get("revision"))
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        entries, revision = restore_backup(data.get("backup"))
        return {"success": True, "entries": [public_entry(item) for item in entries], "revision": revision}
    raise NotFoundError("Unknown IPStreamer API endpoint")
