#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MyHybridIPTV adapter for MyWebUIController.

This module owns the existing MyHybridIPTV subscription-file editor logic.  It is
kept separate from plugin.py so additional supported plugins can be added later
without mixing their file formats or receiver screens with this adapter.
"""

from __future__ import print_function

import fcntl
import hashlib
import json
import os
import re
import secrets
import tempfile
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime
from os.path import basename, dirname, exists, join, realpath
from urllib.parse import urlparse

from enigma import getDesktop

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigText, getConfigListEntry
try:
    from Components.config import ConfigPassword
except Exception:
    ConfigPassword = ConfigText

from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Directories import SCOPE_PLUGINS, resolveFilename
from Tools.LoadPixmap import LoadPixmap

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .common import ControllerError, DataStoreError, NotFoundError, RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, detail_skin, list_skin, load_supported_plugin_pixmap


PLUGIN_ID = "myhybridiptv"
PLUGIN_NAME = "MyHybridIPTV Editor"
PLUGIN_VERSION = "2.1.1-module1-hicons2"
PLUGIN_DESCRIPTION = "Edit MyHybridIPTV M3U, Stalker and Xtream subscription files"
PLUGIN_WEB_PATH = "/myhybridiptv/"
ASYNC_WEB_ENDPOINTS = set()

BASE_DIR = "/etc/enigma2"
FILES = {
    "m3u": join(BASE_DIR, "m3u_config.json"),
    "stalker": join(BASE_DIR, "stalker_config.json"),
    "xtream": join(BASE_DIR, "xtream_config.json"),
}
VALID_TYPES = tuple(FILES.keys())
SERVER_ID_RE = re.compile(r"^[a-f0-9]{32}$")
BACKUP_RE = re.compile(r"^myhybridiptv_backup_\d{8}_\d{6}_[a-f0-9]{6}\.json$")
LOCK = threading.RLock()



def safe_type(value):
    value = str(value or "").strip().lower()
    if value not in VALID_TYPES:
        raise ValidationError("Unsupported server type")
    return value


def make_server_id():
    return uuid.uuid4().hex


def clean_text(value, field, required=True, max_len=2048):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    if "\x00" in value or "\r" in value or "\n" in value:
        raise ValidationError("%s contains invalid characters" % field)
    return value


def validate_http_url(value, field):
    value = clean_text(value, field, required=True, max_len=4096)
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        raise ValidationError("%s must be a valid http:// or https:// URL" % field)
    return value


def normalize_mac(value):
    value = clean_text(value, "MAC address", required=True, max_len=17).upper()
    if not re.match(r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$", value):
        raise ValidationError("MAC address must use XX:XX:XX:XX:XX:XX format")
    return value


def _password_for_web(item, previous):
    incoming = item.get("password", "")
    if isinstance(incoming, str):
        incoming = incoming.strip()
    else:
        raise ValidationError("Password must be text")
    if incoming:
        return clean_text(incoming, "Password", required=True, max_len=1024)
    if previous and previous.get("password"):
        return previous["password"]
    raise ValidationError("Password is required for a new Xtream server")


def normalize_server(typ, item, source="stored", previous=None):
    if not isinstance(item, dict):
        raise ValidationError("Each server entry must be an object")

    raw_id = item.get("id", "")
    if raw_id:
        server_id = clean_text(raw_id, "Server ID", required=True, max_len=32).lower()
        if not SERVER_ID_RE.match(server_id):
            raise ValidationError("Invalid server ID")
    else:
        server_id = make_server_id()

    normalized = {
        "id": server_id,
        "name": clean_text(item.get("name", ""), "Name", required=True, max_len=120),
    }

    if typ == "m3u":
        normalized["url"] = validate_http_url(item.get("url", ""), "M3U URL")
    elif typ == "stalker":
        normalized["portal"] = validate_http_url(item.get("portal", ""), "Portal URL")
        normalized["mac"] = normalize_mac(item.get("mac", ""))
    elif typ == "xtream":
        normalized["host"] = validate_http_url(item.get("host", ""), "Host URL").rstrip("/")
        normalized["user"] = clean_text(item.get("user", ""), "Username", required=True, max_len=256)
        if source == "web":
            normalized["password"] = _password_for_web(item, previous)
        else:
            normalized["password"] = clean_text(item.get("password", ""), "Password", required=True, max_len=1024)
    else:
        raise ValidationError("Unsupported server type")

    return normalized


def normalize_server_list(typ, items, source="stored", previous_items=None):
    typ = safe_type(typ)
    if not isinstance(items, list):
        raise ValidationError("Server collection must be a list")
    if len(items) > 1000:
        raise ValidationError("Too many server records")

    previous_items = previous_items or []
    previous_by_id = {x.get("id"): x for x in previous_items if isinstance(x, dict) and x.get("id")}
    result = []
    seen_names = set()
    seen_ids = set()
    changed = False

    for item in items:
        previous = previous_by_id.get(item.get("id")) if isinstance(item, dict) else None
        normalized = normalize_server(typ, item, source=source, previous=previous)
        key = normalized["name"].casefold()
        if key in seen_names:
            raise ValidationError("Duplicate server name: %s" % normalized["name"])
        if normalized["id"] in seen_ids:
            raise ValidationError("Duplicate server ID")
        seen_names.add(key)
        seen_ids.add(normalized["id"])
        result.append(normalized)
        if item != normalized:
            changed = True
    return result, changed


def public_server(typ, item):
    output = dict(item)
    if typ == "xtream":
        output.pop("password", None)
        output["password_set"] = bool(item.get("password"))
    return output


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def file_lock(path, exclusive=True):
    lock_path = path + ".lock"
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write_bytes(path, payload, mode=0o600):
    folder = dirname(path)
    os.makedirs(folder, mode=0o755, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".myhybridiptv_", suffix=".tmp", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(folder, os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    finally:
        if exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def _encode_servers(items):
    return (json.dumps(items, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def ensure_files():
    os.makedirs(BASE_DIR, mode=0o755, exist_ok=True)
    for file_path in FILES.values():
        if not exists(file_path):
            with file_lock(file_path):
                if not exists(file_path):
                    _atomic_write_bytes(file_path, _encode_servers([]), mode=0o600)
        try:
            os.chmod(file_path, 0o600)
        except Exception:
            pass


def _read_unlocked(typ):
    path = FILES[safe_type(typ)]
    try:
        with open(path, "rb") as handle:
            raw = handle.read()
    except Exception as exc:
        raise DataStoreError("Unable to read %s: %s" % (path, exc))
    try:
        decoded = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise DataStoreError("Invalid JSON in %s: %s" % (path, exc))
    normalized, changed = normalize_server_list(typ, decoded, source="stored")
    return normalized, raw, changed


def load_servers(typ):
    typ = safe_type(typ)
    ensure_files()
    path = FILES[typ]
    with LOCK, file_lock(path, exclusive=True):
        items, raw, changed = _read_unlocked(typ)
        if changed:
            raw = _encode_servers(items)
            _atomic_write_bytes(path, raw, mode=0o600)
        return items, sha256_bytes(raw)


def save_servers(typ, items, expected_revision=None, source="tv"):
    typ = safe_type(typ)
    ensure_files()
    path = FILES[typ]
    with LOCK, file_lock(path, exclusive=True):
        previous, raw, stored_data_changed = _read_unlocked(typ)
        current_revision = sha256_bytes(raw)
        if expected_revision and expected_revision != current_revision:
            raise RevisionConflict("Configuration changed on the receiver. Reload before saving.")
        normalized, normalized_data_changed = normalize_server_list(typ, items, source=source, previous_items=previous)
        payload = _encode_servers(normalized)
        _atomic_write_bytes(path, payload, mode=0o600)
        return normalized, sha256_bytes(payload)


def list_backups():
    """Return MyHybridIPTV bundle backups from the shared controller folder."""
    folder = ensure_backup_dir()
    names = [name for name in os.listdir(folder) if BACKUP_RE.match(name)]
    names.sort(reverse=True)
    return names


def create_backup():
    """Create one backup file containing all MyHybridIPTV subscription types."""
    ensure_files()
    bundle = {
        "plugin": PLUGIN_ID,
        "format": 1,
        "created": datetime.now().isoformat(),
        "files": {},
    }
    for typ in VALID_TYPES:
        items, revision = load_servers(typ)
        bundle["files"][typ] = items
    filename = "myhybridiptv_backup_%s_%s.json" % (
        datetime.now().strftime("%Y%m%d_%H%M%S"), secrets.token_hex(3)
    )
    payload = (json.dumps(bundle, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    _atomic_write_bytes(join(ensure_backup_dir(), filename), payload, mode=0o600)
    return filename


def _safe_backup_path(filename):
    filename = clean_text(filename, "Backup filename", required=True, max_len=200)
    if filename != basename(filename) or not BACKUP_RE.match(filename):
        raise ValidationError("Invalid backup filename")
    folder = realpath(ensure_backup_dir())
    candidate = realpath(join(folder, filename))
    if not candidate.startswith(folder + os.sep) or not exists(candidate):
        raise ValidationError("Backup not found")
    return candidate


def restore_backup(filename, active_type="m3u"):
    """Restore all three MyHybridIPTV files from one validated bundle backup."""
    active_type = safe_type(active_type)
    source = _safe_backup_path(filename)
    try:
        with open(source, "rb") as handle:
            decoded = json.loads(handle.read().decode("utf-8"))
        if not isinstance(decoded, dict) or decoded.get("plugin") != PLUGIN_ID:
            raise ValidationError("Backup is not a MyHybridIPTV bundle")
        files = decoded.get("files")
        if not isinstance(files, dict):
            raise ValidationError("Backup does not contain MyHybridIPTV subscription files")
        normalized_by_type = {}
        for typ in VALID_TYPES:
            normalized, changed = normalize_server_list(typ, files.get(typ, []), source="stored")
            normalized_by_type[typ] = normalized
    except ControllerError:
        raise
    except Exception as exc:
        raise DataStoreError("Backup is invalid: %s" % exc)

    # All sections are validated before any receiver file is changed.
    for typ in VALID_TYPES:
        save_servers(typ, normalized_by_type[typ], source="tv")
    return load_servers(active_type)



def load_server_pixmap():
    """Load the exact real MyHybridIPTV icon from images/supportedplugins."""
    return load_supported_plugin_pixmap("myhybridiptv.png")


class MyHybridIPTVMenuScreen(Screen):
    skin = list_skin("MyHybridIPTV Editor %s" % PLUGIN_VERSION, button_count=1, include_info=False, button_names=["Redkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        ensure_files()
        self.pixmap = load_server_pixmap()
        self.menu_items = [
            (_("M3U Playlists"), _("Manage M3U playlist URLs"), "m3u"),
            (_("Stalker Portals"), _("Manage portal URLs and MAC addresses"), "stalker"),
            (_("Xtream Codes"), _("Manage Xtream host, username and password records"), "xtream"),
            (_("Backup & Restore"), _("Create or restore one MyHybridIPTV bundle backup"), "backup"),
        ]
        self["menu"] = List([])
        self["Greenkey"] = StaticText("")
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(
            ["WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "HelpActions"],
            {
                
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select_item,
                "cancel": self.close,
                "red": self.close,
                "up": self.page_up,
                "down": self.page_down,
            },
            -1,
        )
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        self["menu"].setList([(a, b, self.pixmap, c) for a, b, c in self.menu_items])

    def select_item(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        action = current[3]
        if action in VALID_TYPES:
            self.session.open(ServerListScreen, action)
        elif action == "backup":
            self.session.open(BackupRestoreScreen)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self.menu_items) - 1:
            self["menu"].setIndex(index + 1)



class ServerListScreen(Screen):
    skin = list_skin("Server List", button_count=3, include_info=False)

    def __init__(self, session, file_type):
        Screen.__init__(self, session)
        self.file_type = safe_type(file_type)
        self.pixmap = load_server_pixmap()
        self.servers = []
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add"))
        self["Yellowkey"] = StaticText(_("Edit"))
        self["Redkey"] = StaticText(_("Delete"))
        self["actions"] = ActionMap(
            ["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions", "OkCancelActions", "InfobarEPGActions", "HelpActions"],
            {
                
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.view_server,
                "cancel": self.close,
                "green": self.add_server,
                "yellow": self.edit_server,
                "red": self.delete_server,
                "up": self.page_up,
                "down": self.page_down,
            },
            -1,
        )
        self.setTitle({"m3u": "M3U Playlists", "stalker": "Stalker Portals", "xtream": "Xtream Codes"}[self.file_type])
        self.onLayoutFinish.append(self.load_servers)

    def load_servers(self, *args):
        try:
            self.servers, revision = load_servers(self.file_type)
            rows = []
            for index, item in enumerate(self.servers):
                if self.file_type == "m3u":
                    description = item["url"]
                elif self.file_type == "stalker":
                    description = "%s | %s" % (item["portal"], item["mac"])
                else:
                    description = "%s | %s" % (item["host"], item["user"])
                rows.append((item["name"], description, self.pixmap, index))
            if not rows:
                rows = [(_("No servers found"), _("Press Add to create a record"), self.pixmap, None)]
            self["menu"].setList(rows)
        except Exception as exc:
            self.servers = []
            self["menu"].setList([(_("Configuration error"), str(exc), self.pixmap, None)])
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def selected(self):
        current = self["menu"].getCurrent()
        if current and current[3] is not None and current[3] < len(self.servers):
            return current[3], self.servers[current[3]]
        return None, None

    def view_server(self):
        selected_index, item = self.selected()
        if item:
            self.session.open(ServerViewScreen, item, self.file_type)

    def add_server(self):
        self.session.openWithCallback(self.load_servers, EditServerScreen, self.file_type, "add")

    def edit_server(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(self.load_servers, EditServerScreen, self.file_type, "edit", item, index)

    def delete_server(self):
        index, item = self.selected()
        if item:
            self.session.openWithCallback(lambda answer: self.confirm_delete(answer, index), MessageBox,
                                          "Delete server: %s?" % item["name"], MessageBox.TYPE_YESNO)

    def confirm_delete(self, answer, index):
        if not answer:
            return
        try:
            servers, revision = load_servers(self.file_type)
            if index >= len(servers):
                raise ValidationError("Server no longer exists")
            servers.pop(index)
            save_servers(self.file_type, servers, source="tv")
            self.load_servers()
            self.session.open(MessageBox, _("Server deleted successfully"), MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def page_up(self):
        index = self["menu"].getIndex()
        if index > 0:
            self["menu"].setIndex(index - 1)

    def page_down(self):
        index = self["menu"].getIndex()
        if index < len(self["menu"].list) - 1:
            self["menu"].setIndex(index + 1)


class ServerViewScreen(Screen):
    skin = detail_skin()

    def __init__(self, session, server_data, file_type):
        Screen.__init__(self, session)
        self.server_data = server_data
        self.file_type = file_type
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["DirectionActions", "ColorActions", "OkCancelActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)
        self.setTitle("Server: %s" % server_data.get("name", "Unknown"))
        self.onLayoutFinish.append(self.display)

    def display(self):
        lines = ["=" * 60, "SERVER DETAILS - %s" % self.server_data.get("name", "Unknown"), "=" * 60]
        for key, value in self.server_data.items():
            if key == "password":
                value = "********"
            lines.append("%-15s : %s" % (key, value))
        self["text"].setText("\n".join(lines))


class EditServerScreen(Screen, ConfigListScreen):
    skin = config_skin("Server Editor")

    def __init__(self, session, file_type, mode="add", server_data=None, server_index=None):
        Screen.__init__(self, session)
        self.file_type = safe_type(file_type)
        self.mode = mode
        self.server_index = server_index
        self.server_data = dict(server_data or {})
        self.name = ConfigText(default=self.server_data.get("name", ""), fixed_size=False)
        if self.file_type == "m3u":
            self.url = ConfigText(default=self.server_data.get("url", ""), fixed_size=False)
        elif self.file_type == "stalker":
            self.portal = ConfigText(default=self.server_data.get("portal", ""), fixed_size=False)
            self.mac = ConfigText(default=self.server_data.get("mac", ""), fixed_size=False)
        else:
            self.host = ConfigText(default=self.server_data.get("host", ""), fixed_size=False)
            self.user = ConfigText(default=self.server_data.get("user", ""), fixed_size=False)
            self.password = ConfigPassword(default=self.server_data.get("password", ""), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)
        self["Greenkey"] = StaticText(_("Save"))
        self["Redkey"] = StaticText(_("Cancel"))
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions", "MenuActions", "ColorActions", "InfobarEPGActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "green": self.save_config,
            "ok": self.save_config,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.setTitle(_("Add Server") if mode == "add" else _("Edit Server"))
        self.create_setup()

    def create_setup(self):
        rows = [getConfigListEntry(_("Name"), self.name)]
        if self.file_type == "m3u":
            rows.append(getConfigListEntry(_("M3U URL"), self.url))
        elif self.file_type == "stalker":
            rows.append(getConfigListEntry(_("Portal URL"), self.portal))
            rows.append(getConfigListEntry(_("MAC Address"), self.mac))
        else:
            rows.append(getConfigListEntry(_("Host URL"), self.host))
            rows.append(getConfigListEntry(_("Username"), self.user))
            rows.append(getConfigListEntry(_("Password"), self.password))
        self.list = rows
        self["config"].setList(rows)

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current:
            label, field = current
            self.session.openWithCallback(lambda text: self.keyboard_done(field, text), VirtualKeyBoard,
                                          title="Enter %s" % label, text=field.value)

    def keyboard_done(self, field, text):
        if text is not None:
            field.value = text
            self["config"].invalidateCurrent()

    def collect(self):
        item = {"id": self.server_data.get("id") or make_server_id(), "name": self.name.value}
        if self.file_type == "m3u":
            item["url"] = self.url.value
        elif self.file_type == "stalker":
            item["portal"] = self.portal.value
            item["mac"] = self.mac.value
        else:
            item["host"] = self.host.value
            item["user"] = self.user.value
            item["password"] = self.password.value
        return item

    def save_config(self):
        try:
            item = normalize_server(self.file_type, self.collect(), source="tv")
            servers, revision = load_servers(self.file_type)
            if self.mode == "add":
                servers.append(item)
            else:
                if self.server_index is None or self.server_index >= len(servers):
                    raise ValidationError("Server no longer exists")
                servers[self.server_index] = item
            save_servers(self.file_type, servers, source="tv")
            self.session.open(MessageBox, _("Server saved successfully"), MessageBox.TYPE_INFO, timeout=3)
            self.close(True)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("MyHybridIPTV Backup & Restore", button_count=2, include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_server_pixmap()
        self.menu_entries = [
            (_("Backup MyHybridIPTV"), _("Create one backup containing M3U, Stalker and Xtream files"), "backup"),
            (_("Restore MyHybridIPTV"), _("Restore all MyHybridIPTV subscription files from one backup"), "restore"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c) for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Redkey"] = StaticText(_("Back"))
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        try:
            if current[3] == "backup":
                self.session.open(MessageBox, "Backup created: %s" % create_backup(), MessageBox.TYPE_INFO)
            else:
                choices = [(name, name) for name in list_backups()]
                if not choices:
                    raise ValidationError("No backups found")
                self.session.openWithCallback(self.restore_choice, ChoiceBox, title="Select backup to restore", list=choices)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)

    def restore_choice(self, choice):
        if not choice:
            return
        try:
            restore_backup(choice[1])
            self.session.open(MessageBox, "MyHybridIPTV files restored successfully", MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR)



def manifest():
    return {
        "id": PLUGIN_ID,
        "name": "MyHybridIPTV",
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(MyHybridIPTVMenuScreen)


def _query_text(args, name, default=""):
    key = name.encode("utf-8")
    values = args.get(key, []) if isinstance(args, dict) else []
    if not values:
        return default
    value = values[0]
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


def web_get(endpoint, args):
    if endpoint == "info":
        payload = manifest()
        payload["success"] = True
        return payload
    if endpoint == "playlists":
        typ = safe_type(_query_text(args, "type", "m3u"))
        items, revision = load_servers(typ)
        return {"success": True, "servers": [public_server(typ, item) for item in items], "revision": revision}
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise NotFoundError("Unknown MyHybridIPTV API endpoint")


def web_post(endpoint, data):
    if not isinstance(data, dict):
        raise ValidationError("JSON request must be an object")
    if endpoint == "update":
        typ = safe_type(data.get("type"))
        items, revision = save_servers(typ, data.get("servers", []), expected_revision=data.get("revision"), source="web")
        return {"success": True, "servers": [public_server(typ, item) for item in items], "revision": revision}
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        typ = safe_type(data.get("type") or "m3u")
        items, revision = restore_backup(data.get("backup"), active_type=typ)
        return {"success": True, "servers": [public_server(typ, item) for item in items], "revision": revision}
    raise NotFoundError("Unknown MyHybridIPTV API endpoint")
