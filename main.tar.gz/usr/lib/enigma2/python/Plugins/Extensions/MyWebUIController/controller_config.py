#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared MyWebUIController configuration.

Only controller-wide settings live here: web port, automatic startup, one
shared backup directory, and the default Web UI theme. Supported-plugin adapters
reuse these values and do not create module-specific settings.
"""

from __future__ import print_function

import os

from Components.config import ConfigInteger, ConfigSelection, ConfigSubsection, ConfigText, ConfigYesNo, config

from .common import ValidationError


DEFAULT_WEB_PORT = 5566
DEFAULT_BACKUP_DIR = "/etc/enigma2/mywebuicontroller_backups/"
DEFAULT_WEB_THEME = "light"
DEFAULT_PLUGIN_REORDER_ENABLED = True
DEFAULT_PLUGIN_ORDER = "myhybridiptv,xstreamity,estalker,ipaudiopro,ipaudioplus,bmx,ipstreamer"


if not hasattr(config.plugins, "MyWebUIController"):
    config.plugins.MyWebUIController = ConfigSubsection()

cfg = config.plugins.MyWebUIController
if not hasattr(cfg, "web_port"):
    cfg.web_port = ConfigInteger(default=DEFAULT_WEB_PORT, limits=(1, 65535))
if not hasattr(cfg, "web_autostart"):
    cfg.web_autostart = ConfigYesNo(default=False)
if not hasattr(cfg, "backup_dir"):
    cfg.backup_dir = ConfigText(default=DEFAULT_BACKUP_DIR, fixed_size=False)
if not hasattr(cfg, "web_theme"):
    cfg.web_theme = ConfigSelection(default=DEFAULT_WEB_THEME, choices=[("light", "Light"), ("dark", "Dark")])
if not hasattr(cfg, "allow_plugin_reorder"):
    cfg.allow_plugin_reorder = ConfigYesNo(default=DEFAULT_PLUGIN_REORDER_ENABLED)
if not hasattr(cfg, "plugin_order"):
    # Internal persisted order.  It is intentionally not exposed as free text in
    # the settings screen; users arrange the list safely with CH+ and CH-.
    cfg.plugin_order = ConfigText(default=DEFAULT_PLUGIN_ORDER, fixed_size=False)


def normalize_web_theme(value=None):
    """Return a validated Web UI theme name."""
    raw = cfg.web_theme.value if value is None else value
    if raw is None:
        raw = DEFAULT_WEB_THEME
    raw = str(raw).strip().lower()
    if raw not in ("light", "dark"):
        raise ValidationError("Web UI theme must be light or dark")
    return raw



def normalize_plugin_order(available_ids, value=None):
    """Return a safe persisted adapter order and append newly supported IDs.

    Stored values are comma-separated adapter IDs. Invalid, duplicate, removed or
    unknown IDs are ignored. Any adapter added by a future controller update is
    appended automatically using the built-in supported-plugin order.
    """
    available = [str(plugin_id).strip() for plugin_id in available_ids if str(plugin_id).strip()]
    allowed = set(available)
    raw = cfg.plugin_order.value if value is None else value
    if raw is None:
        raw = ""
    if not isinstance(raw, str):
        raw = str(raw)
    result = []
    seen = set()
    for plugin_id in raw.split(","):
        plugin_id = plugin_id.strip()
        if plugin_id in allowed and plugin_id not in seen:
            result.append(plugin_id)
            seen.add(plugin_id)
    for plugin_id in available:
        if plugin_id not in seen:
            result.append(plugin_id)
            seen.add(plugin_id)
    return result

def normalize_backup_dir(value=None):
    """Validate and normalize the shared backup directory path."""
    raw = cfg.backup_dir.value if value is None else value
    if raw is None:
        raw = ""
    if not isinstance(raw, str):
        raise ValidationError("Backup directory must be text")
    raw = raw.strip() or DEFAULT_BACKUP_DIR
    if "\x00" in raw or "\r" in raw or "\n" in raw:
        raise ValidationError("Backup directory contains invalid characters")
    if not os.path.isabs(raw):
        raise ValidationError("Backup directory must be an absolute path")
    return os.path.abspath(raw)


def ensure_backup_dir():
    """Create and return the shared backup directory used by every adapter."""
    folder = normalize_backup_dir()
    os.makedirs(folder, mode=0o700, exist_ok=True)
    try:
        os.chmod(folder, 0o700)
    except Exception:
        pass
    return folder
