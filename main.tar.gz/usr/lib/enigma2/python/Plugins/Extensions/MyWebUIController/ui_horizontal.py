#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Horizontal receiver-list skin helpers for MyWebUIController.

This module provides dynamically scaled list and configuration skins based on
the receiver's current resolution.
"""

from __future__ import print_function

import os
from xml.sax.saxutils import escape as xml_escape

from enigma import getDesktop  # type: ignore
from Tools.LoadPixmap import LoadPixmap


PLUGIN_PATH = os.path.dirname(__file__)
SUPPORTED_ICON_DIR = os.path.join(PLUGIN_PATH, "images", "supportedplugins")


def screen_profile():
    size = getDesktop(0).size()
    width = size.width()
    height = size.height()
    if width >= 1920 and height >= 1000:
        return {"w": 1100, "h": 820, "margin": 26, "font": 30, "small": 24, "row": 72, "keyw": 230, "keyh": 44}
    if width >= 1280 and height >= 700:
        return {"w": 920, "h": 650, "margin": 20, "font": 24, "small": 20, "row": 58, "keyw": 190, "keyh": 38}
    return {"w": 690, "h": 520, "margin": 14, "font": 18, "small": 16, "row": 46, "keyw": 150, "keyh": 32}


def xml_attr(value):
    return xml_escape(str(value), {'"': '&quot;', "'": '&apos;'})


def load_supported_plugin_pixmap(filename):
    filename = os.path.basename(str(filename or "").strip())
    if not filename:
        return None
    path = os.path.join(SUPPORTED_ICON_DIR, filename)
    try:
        if not os.path.isfile(path):
            print("[MyWebUIController] Supported plugin icon not found: %s" % path)
            return None
        pixmap = LoadPixmap(cached=False, path=path)
        if pixmap is None:
            print("[MyWebUIController] Unable to load supported plugin icon: %s" % path)
        return pixmap
    except Exception as exc:
        print("[MyWebUIController] Unable to load supported plugin icon %s: %s" % (
            path, exc))
        return None


def list_skin(title, button_count=3, include_info=False, button_names=None):
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    info_h = 220 if include_info else 0
    key_y = h - p["keyh"] - 16

    header_h = 36
    list_y = m + header_h + 8

    # Calculate available space and snap to an exact multiple of the row height
    row_h = 60
    raw_list_h = key_y - list_y - (info_h + 12 if include_info else 0)
    list_h = (raw_list_h // row_h) * row_h

    default_names = ["Redkey", "Greenkey", "Yellowkey", "Bluekey"]
    key_names = (button_names or default_names)[:button_count]
    color_map = {"Greenkey": "#00aa00", "Yellowkey": "#d6b700",
                 "Redkey": "#cc2222", "Bluekey": "#2255cc"}
    key_colors = [color_map[name] for name in key_names]

    list_w = w - 2 * m
    icon_x, icon_y, icon_w, icon_h = 4, 7, 120, 45
    name_x = 140
    if list_w >= 1000:
        name_w = 285
    elif list_w >= 820:
        name_w = 235
    else:
        name_w = 175
    gap = 14
    desc_x = name_x + name_w + gap
    desc_w = max(100, list_w - desc_x - 8)
    name_font = min(p["font"], 24)
    desc_font = min(p["small"], 20)

    parts = [
        '<screen position="center,center" size="%s,%s" title="%s">' % (
            w, h, xml_attr(title)),
        '<widget source="title" render="Label" position="%s,%s" size="%s,%s" font="Regular;%s" foregroundColor="#f0a30a" backgroundColor="#000000" transparent="1" halign="left" valign="center" />' % (
            m, m, list_w, header_h, p["font"]),
        '<eLabel backgroundColor="#333333" position="%s,%s" size="%s,1" />' % (
            m, m + header_h + 4, list_w),
        '<widget source="menu" render="Listbox" position="%s,%s" size="%s,%s" scrollbarMode="showOnDemand">' % (
            m, list_y, list_w, list_h),
        '<convert type="TemplatedMultiContent">',
        '{"template": [',
        'MultiContentEntryPixmapAlphaTest(pos = (%s, %s), size = (%s, %s), png = 2),' % (
            icon_x, icon_y, icon_w, icon_h),
        'MultiContentEntryText(pos = (%s, %s), size = (%s, %s), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),' % (
            name_x, 0, name_w, row_h),
        'MultiContentEntryText(pos = (%s, %s), size = (%s, %s), font=1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 1),' % (
            desc_x, 0, desc_w, row_h),
        '], "fonts": [gFont("Regular", %s), gFont("Regular", %s)], "itemHeight": %s}' % (
            name_font, desc_font, row_h),
        '</convert></widget>',
    ]
    if include_info:
        parts.append('<widget name="webinfo" position="%s,%s" size="%s,%s" font="Regular;%s" />' %
                     (m, list_y + list_h + 8, list_w, info_h, p["small"]))
    for idx, (name, color) in enumerate(zip(key_names, key_colors)):
        x = m + idx * (p["keyw"] + 8)
        parts.append('<widget source="%s" render="Label" position="%s,%s" size="%s,%s" font="Regular;%s" halign="center" valign="center" foregroundColor="white" transparent="1" />' %
                     (name, x, key_y, p["keyw"], p["keyh"], p["small"]))
        parts.append('<eLabel backgroundColor="%s" position="%s,%s" size="%s,5" />' %
                     (color, x, key_y + p["keyh"] + 2, p["keyw"]))
    parts.append('</screen>')
    return "\n".join(parts)


def config_skin(title, include_yellow=False, include_blue=False, button_names=None):
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    key_y = h - p["keyh"] - 16
    header_h = 36
    cfg_y = m + header_h + 8
    cfg_w = w - 2 * m

    # Snap config list to an exact multiple of the row height
    raw_cfg_h = key_y - cfg_y - 10
    cfg_h = (raw_cfg_h // p["row"]) * p["row"]

    parts = [
        '<screen position="center,center" size="%s,%s" title="%s">' % (
            w, h, xml_attr(title)),
        '<widget source="title" render="Label" position="%s,%s" size="%s,%s" font="Regular;%s" foregroundColor="#f0a30a" backgroundColor="#000000" transparent="1" halign="left" valign="center" />' % (
            m, m, cfg_w, header_h, p["font"]),
        '<eLabel backgroundColor="#333333" position="%s,%s" size="%s,1" />' % (
            m, m + header_h + 4, cfg_w),
        # Added valueFont to match the entry font size
        '<widget name="config" position="%s,%s" size="%s,%s" scrollbarMode="showOnDemand" font="Regular;%s" valueFont="Regular;%s" itemHeight="%s" />' % (
            m, cfg_y, cfg_w, cfg_h, p["font"], p["font"], p["row"]),
    ]
    color_map = {"Redkey": "#cc2222", "Greenkey": "#00aa00",
                 "Yellowkey": "#d6b700", "Bluekey": "#2255cc"}
    if button_names is not None:
        names = list(button_names)
    else:
        names = ["Redkey", "Greenkey"]
        if include_yellow:
            names = ["Redkey", "Greenkey", "Yellowkey"]
        if include_blue:
            names.append("Bluekey")
    buttons = [(name, color_map[name]) for name in names]
    for idx, (name, color) in enumerate(buttons):
        x = m + idx * (p["keyw"] + 8)
        parts.append('<widget source="%s" render="Label" position="%s,%s" size="%s,%s" font="Regular;%s" halign="center" valign="center" foregroundColor="white" transparent="1" />' %
                     (name, x, key_y, p["keyw"], p["keyh"], p["small"]))
        parts.append('<eLabel backgroundColor="%s" position="%s,%s" size="%s,5" />' %
                     (color, x, key_y + p["keyh"] + 2, p["keyw"]))
    parts.append('</screen>')
    return "\n".join(parts)


def detail_skin(title="Details"):
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    key_y = h - p["keyh"] - 16
    header_h = 36
    content_y = m + header_h + 8
    content_w = w - 2 * m
    content_h = key_y - content_y - 8

    return """
    <screen position="center,center" size="%(w)s,%(h)s" title="%(title)s">
        <widget source="title" render="Label" position="%(m)s,%(m)s" size="%(cw)s,%(hh)s" font="Regular;%(font)s" foregroundColor="#f0a30a" backgroundColor="#000000" transparent="1" halign="left" valign="center" />
        <eLabel backgroundColor="#333333" position="%(m)s,%(line_top)s" size="%(cw)s,1" />
        <widget name="text" position="%(m)s,%(cy)s" size="%(cw)s,%(ch)s" font="Console;%(small)s" />
        <widget source="Redkey" render="Label" position="%(m)s,%(ky)s" size="%(kw)s,%(kh)s" font="Regular;%(small)s" halign="center" valign="center" foregroundColor="white" transparent="1" />
        <eLabel backgroundColor="#cc2222" position="%(m)s,%(liney)s" size="%(kw)s,5" />
    </screen>
    """ % {
        "w": w, "h": h, "title": xml_attr(title), "m": m,
        "hh": header_h, "line_top": m + header_h + 4, "cy": content_y, "cw": content_w, "ch": content_h,
        "font": p["font"], "small": p["small"], "ky": key_y, "kw": p["keyw"], "kh": p["keyh"],
        "liney": key_y + p["keyh"] + 2,
    }
