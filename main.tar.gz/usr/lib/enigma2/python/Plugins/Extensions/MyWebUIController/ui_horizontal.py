#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Horizontal receiver-list skin helpers for MyWebUIController v1.8.3.

This module intentionally has a new filename.  It prevents old ui.py bytecode or
an earlier imported helper from retaining the former two-line list template.
"""

from __future__ import print_function

import os
from xml.sax.saxutils import escape as xml_escape

from enigma import getDesktop, gFont
from Tools.LoadPixmap import LoadPixmap


PLUGIN_PATH = os.path.dirname(__file__)
SUPPORTED_ICON_DIR = os.path.join(PLUGIN_PATH, "images", "supportedplugins")


def screen_profile():
    size = getDesktop(0).size()
    width = size.width()
    height = size.height()
    if width >= 1920 and height >= 1000:
        return {"w": 1100, "h": 820, "margin": 26, "font": 30, "small": 24, "row": 72, "keyw": 230, "keyh": 44}
    if width >= 1280 and height >= 700:
        return {"w": 920, "h": 650, "margin": 20, "font": 24, "small": 20, "row": 58, "keyw": 190, "keyh": 38}
    return {"w": 690, "h": 520, "margin": 14, "font": 18, "small": 16, "row": 46, "keyw": 150, "keyh": 32}


def xml_attr(value):
    return xml_escape(str(value), {'"': '&quot;', "'": '&apos;'})


def load_supported_plugin_pixmap(filename):
    """Load one exact PNG from images/supportedplugins without a generic fallback.

    Expected receiver files:
      - myhybridiptv.png
      - xtreamity.png
      - estalker.png

    Returning None when an icon is missing is deliberate: a missing real icon is
    easier to notice than silently showing the wrong generic server icon.
    """
    filename = os.path.basename(str(filename or "").strip())
    if not filename:
        return None
    path = os.path.join(SUPPORTED_ICON_DIR, filename)
    try:
        if not os.path.isfile(path):
            print("[MyWebUIController] Supported plugin icon not found: %s" % path)
            return None
        pixmap = LoadPixmap(cached=False, path=path)
        if pixmap is None:
            print("[MyWebUIController] Unable to load supported plugin icon: %s" % path)
        return pixmap
    except Exception as exc:
        print("[MyWebUIController] Unable to load supported plugin icon %s: %s" % (path, exc))
        return None


def list_skin(title, button_count=3, include_info=False, button_names=None):
    """Build a fixed 60px horizontal list: 120x45 PNG | name | description."""
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    info_h = 220 if include_info else 0
    key_y = h - p["keyh"] - 16
    list_h = key_y - m - (info_h + 12 if include_info else 0)
    default_names = ["Redkey", "Greenkey", "Yellowkey", "Bluekey"]
    key_names = (button_names or default_names)[:button_count]
    color_map = {"Greenkey": "#00aa00", "Yellowkey": "#d6b700", "Redkey": "#cc2222", "Bluekey": "#2255cc"}
    key_colors = [color_map[name] for name in key_names]

    row_h = 60
    list_w = w - 2 * m
    icon_x, icon_y, icon_w, icon_h = 4, 7, 120, 45
    name_x = 140
    if list_w >= 1000:
        name_w = 285
    elif list_w >= 820:
        name_w = 235
    else:
        name_w = 175
    gap = 14
    desc_x = name_x + name_w + gap
    desc_w = max(100, list_w - desc_x - 8)
    name_font = min(p["font"], 24)
    desc_font = min(p["small"], 20)
    name_y = max(0, (row_h - name_font) // 2 - 1)
    desc_y = max(0, (row_h - desc_font) // 2)

    parts = [
        '<screen position="center,center" size="%s,%s" title="%s">' % (w, h, xml_attr(title)),
        '<widget source="menu" render="Listbox" position="%s,%s" size="%s,%s" scrollbarMode="showOnDemand">' % (m, m, list_w, list_h),
        '<convert type="TemplatedMultiContent">',
        '{"template": [',
        'MultiContentEntryPixmapAlphaTest(pos = (%s, %s), size = (%s, %s), png = 2),' % (icon_x, icon_y, icon_w, icon_h),
        'MultiContentEntryText(pos = (%s, %s), size = (%s, %s), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),' % (name_x, 0, name_w, row_h),
        'MultiContentEntryText(pos = (%s, %s), size = (%s, %s), font=1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 1),' % (desc_x, 0, desc_w, row_h),
        '], "fonts": [gFont("Regular", %s), gFont("Regular", %s)], "itemHeight": %s}' % (name_font, desc_font, row_h),
        '</convert></widget>',
    ]
    if include_info:
        parts.append('<widget name="webinfo" position="%s,%s" size="%s,%s" font="Regular;%s" />' % (m, list_h + m + 8, w - 2*m, info_h, p["small"]))
    for idx, (name, color) in enumerate(zip(key_names, key_colors)):
        x = m + idx * (p["keyw"] + 8)
        parts.append('<widget source="%s" render="Label" position="%s,%s" size="%s,%s" font="Regular;%s" halign="center" valign="center" foregroundColor="white" transparent="1" />' % (name, x, key_y, p["keyw"], p["keyh"], p["small"]))
        parts.append('<eLabel backgroundColor="%s" position="%s,%s" size="%s,5" />' % (color, x, key_y + p["keyh"] + 2, p["keyw"]))
    parts.append('</screen>')
    return "\n".join(parts)


def config_skin(title, include_yellow=False, include_blue=False, button_names=None):
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    key_y = h - p["keyh"] - 16
    parts = [
        '<screen position="center,center" size="%s,%s" title="%s">' % (w, h, xml_attr(title)),
        '<widget name="config" position="%s,%s" size="%s,%s" scrollbarMode="showOnDemand" font="Regular;%s" itemHeight="%s" />' % (m, m, w - 2*m, key_y - m - 10, p["font"], p["row"]),
    ]
    color_map = {"Redkey": "#cc2222", "Greenkey": "#00aa00", "Yellowkey": "#d6b700", "Bluekey": "#2255cc"}
    if button_names is not None:
        names = list(button_names)
    else:
        names = ["Redkey", "Greenkey"]
        if include_yellow:
            names = ["Redkey", "Greenkey", "Yellowkey"]
        if include_blue:
            names.append("Bluekey")
    buttons = [(name, color_map[name]) for name in names]
    for idx, (name, color) in enumerate(buttons):
        x = m + idx * (p["keyw"] + 8)
        parts.append('<widget source="%s" render="Label" position="%s,%s" size="%s,%s" font="Regular;%s" halign="center" valign="center" foregroundColor="white" transparent="1" />' % (name, x, key_y, p["keyw"], p["keyh"], p["small"]))
        parts.append('<eLabel backgroundColor="%s" position="%s,%s" size="%s,5" />' % (color, x, key_y + p["keyh"] + 2, p["keyw"]))
    parts.append('</screen>')
    return "\n".join(parts)


def detail_skin(title="Server Details"):
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    key_y = h - p["keyh"] - 16
    return """
    <screen position="center,center" size="%(w)s,%(h)s" title="%(title)s">
        <widget name="text" position="%(m)s,%(m)s" size="%(cw)s,%(ch)s" font="Console;%(small)s" />
        <widget source="Redkey" render="Label" position="%(m)s,%(ky)s" size="%(kw)s,%(kh)s" font="Regular;%(small)s" halign="center" valign="center" foregroundColor="white" transparent="1" />
        <eLabel backgroundColor="#cc2222" position="%(m)s,%(liney)s" size="%(kw)s,5" />
    </screen>
    """ % {
        "w": w, "h": h, "title": xml_attr(title), "m": m, "cw": w - 2*m, "ch": key_y - m - 8,
        "small": p["small"], "ky": key_y, "kw": p["keyw"], "kh": p["keyh"], "liney": key_y + p["keyh"] + 2,
    }
