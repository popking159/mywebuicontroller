#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GTIPTVPlayerPro dual-file adapter for MyWebUIController.

Manages:
  - Stalker portals: /etc/enigma2/gtiptvplayer/stalker.txt
  - Xtream playlists: /etc/enigma2/gtiptvplayer/playlists.txt
Supports Add, Edit, Delete, Reorder (Up/Down), and Backup/Restore.
"""

from __future__ import print_function

import fcntl
import hashlib
import os
import re
import secrets
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime
from os.path import dirname, exists, join, realpath
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import ConfigSelection, ConfigText, getConfigListEntry
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Tools.International import _  # type: ignore
except Exception:
    def _(txt):
        return txt

from .metadata import PLUGIN_NAME, PLUGIN_VERSION
from .common import RevisionConflict, ValidationError
from .controller_config import ensure_backup_dir
from .help_screens import open_adapter_help
from .ui_horizontal import config_skin, list_skin, load_supported_plugin_pixmap

PLUGIN_ID = "gtiptvplayer"
ADAPTER_NAME = "GTIPTVPlayerPro"
PLUGIN_DESCRIPTION = "Edit Stalker & Xtream playlists in /etc/enigma2/gtiptvplayer/"
PLUGIN_WEB_PATH = "/gtiptvplayer/"
ASYNC_WEB_ENDPOINTS = set()

SOURCE_PLUGIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/GTIPTVPlayerPro/"
CONFIG_DIR = "/etc/enigma2/gtiptvplayer"
STALKER_FILE = join(CONFIG_DIR, "stalker.txt")
PLAYLIST_FILE = join(CONFIG_DIR, "playlists.txt")

BACKUP_RE = re.compile(
    r"^gtiptvplayer_backup_\d{8}_\d{6}_[a-f0-9]{6}\.tar\.gz$")
MAC_RE = re.compile(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")
MAX_FILE_BYTES = 4 * 1024 * 1024
LOCK = threading.RLock()


def clean_text(value, field, required=True, max_len=2048):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValidationError("%s must be text" % field)
    value = value.strip()
    if required and not value:
        raise ValidationError("%s is required" % field)
    if len(value) > max_len:
        raise ValidationError("%s is too long" % field)
    return value


def normalize_mac(value):
    raw = clean_text(value, "MAC Address", required=True, max_len=64)
    cleaned = re.sub(r"[^0-9A-Fa-f]", "", raw)
    if len(cleaned) != 12:
        raise ValidationError("MAC address must contain 12 hex characters")
    mac = ":".join(cleaned[i:i + 2].upper() for i in range(0, 12, 2))
    if not MAC_RE.match(mac):
        raise ValidationError("Invalid MAC address format")
    return mac


def make_id(*parts):
    payload = "\x00".join(str(p) for p in parts).encode("utf-8", "replace")
    return hashlib.md5(payload).hexdigest()


@contextmanager
def file_lock(path):
    lock_path = path + ".lock"
    os.makedirs(dirname(lock_path), mode=0o755, exist_ok=True)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _atomic_write(path, content):
    os.makedirs(dirname(path), mode=0o755, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".gtiptv_", dir=dirname(path))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content.encode("utf-8")
                    if isinstance(content, str) else content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if exists(tmp):
            try:
                os.unlink(tmp)
            except Exception:
                pass


def ensure_files():
    os.makedirs(CONFIG_DIR, mode=0o755, exist_ok=True)
    for path in (STALKER_FILE, PLAYLIST_FILE):
        if not exists(path):
            _atomic_write(path, "")


def parse_stalker_entries(content):
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    entries = []
    i = 0
    while i < len(lines) - 1:
        url = lines[i]
        mac = lines[i + 1]
        try:
            mac = normalize_mac(mac)
            entries.append(
                {"id": make_id("stalker", len(entries), url, mac), "url": url, "mac": mac})
            i += 2
        except Exception:
            i += 1
    return entries


def encode_stalker_entries(entries):
    lines = []
    for item in entries:
        lines.append(clean_text(item.get("url"), "Portal URL"))
        lines.append(normalize_mac(item.get("mac")))
        lines.append("")
    return "\n".join(lines).strip() + "\n" if lines else ""


def parse_playlist_entries(content):
    entries = []
    for idx, raw in enumerate(content.splitlines()):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parsed = urlparse(line)
        qs = parse_qs(parsed.query)
        port = str(parsed.port or (443 if parsed.scheme == "https" else 80))
        host = "%s://%s" % (parsed.scheme or "http", parsed.hostname or "")
        username = qs.get("username", [""])[0]
        password = qs.get("password", [""])[0]
        type_opt = qs.get("type", ["m3u_plus"])[0]
        output_opt = qs.get("output", ["ts"])[0]
        entries.append({
            "id": make_id("playlist", idx, host, port, username),
            "host": host,
            "port": port,
            "username": username,
            "password": password,
            "type": type_opt,
            "output": output_opt,
        })
    return entries


def encode_playlist_entries(entries):
    lines = []
    for item in entries:
        host = clean_text(item.get("host"), "URL")
        parsed = urlparse(host)
        scheme = parsed.scheme or "http"
        hostname = parsed.hostname or host.replace(
            "http://", "").replace("https://", "").split("/")[0].split(":")[0]
        port = int(clean_text(str(item.get("port", 80)), "Port"))
        netloc = "%s:%s" % (hostname, port)
        query = urlencode({
            "username": clean_text(item.get("username"), "Username"),
            "password": clean_text(item.get("password", ""), "Password", required=False),
            "type": item.get("type", "m3u_plus"),
            "output": item.get("output", "ts"),
        })
        lines.append(urlunparse((scheme, netloc, "/get.php", "", query, "")))
    return "\n".join(lines) + "\n" if lines else ""


def load_all():
    ensure_files()
    with LOCK:
        with open(STALKER_FILE, "r", encoding="utf-8", errors="replace") as f:
            stalker_content = f.read(MAX_FILE_BYTES)
        with open(PLAYLIST_FILE, "r", encoding="utf-8", errors="replace") as f:
            playlist_content = f.read(MAX_FILE_BYTES)
        rev = hashlib.sha256(
            (stalker_content + playlist_content).encode("utf-8")).hexdigest()
        return {
            "stalker": parse_stalker_entries(stalker_content),
            "playlists": parse_playlist_entries(playlist_content),
            "revision": rev,
        }


def save_all(data, expected_rev=None):
    ensure_files()
    stalker_raw = encode_stalker_entries(data.get("stalker", []))
    playlist_raw = encode_playlist_entries(data.get("playlists", []))
    with LOCK, file_lock(STALKER_FILE), file_lock(PLAYLIST_FILE):
        current = load_all()
        if expected_rev and current["revision"] != expected_rev:
            raise RevisionConflict("Files have been modified on receiver.")
        _atomic_write(STALKER_FILE, stalker_raw)
        _atomic_write(PLAYLIST_FILE, playlist_raw)
    return load_all()


def list_backups():
    folder = ensure_backup_dir()
    return sorted([f for f in os.listdir(folder) if BACKUP_RE.match(f)], reverse=True)


def create_backup():
    import tarfile
    ensure_files()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = "gtiptvplayer_backup_%s_%s.tar.gz" % (stamp, secrets.token_hex(3))
    dest = join(ensure_backup_dir(), fname)
    with tarfile.open(dest, "w:gz") as tar:
        if exists(STALKER_FILE):
            tar.add(STALKER_FILE, arcname="stalker.txt")
        if exists(PLAYLIST_FILE):
            tar.add(PLAYLIST_FILE, arcname="playlists.txt")
    return fname


def restore_backup(filename):
    import tarfile
    folder = ensure_backup_dir()
    source = realpath(join(folder, filename))
    if not source.startswith(folder + os.sep) or not exists(source):
        raise ValidationError("Backup file not found")
    with LOCK, file_lock(STALKER_FILE), file_lock(PLAYLIST_FILE):
        with tarfile.open(source, "r:gz") as tar:
            for member in tar.getmembers():
                if member.name == "stalker.txt":
                    f = tar.extractfile(member)
                    if f:
                        _atomic_write(STALKER_FILE, f.read())
                elif member.name == "playlists.txt":
                    f = tar.extractfile(member)
                    if f:
                        _atomic_write(PLAYLIST_FILE, f.read())
    return load_all()


def load_plugin_pixmap():
    return load_supported_plugin_pixmap("gtiptvplayer.png")


# --- Receiver UI Screens ---

class GTIPTVMainMenuScreen(Screen):
    skin = list_skin("GTIPTVPlayerPro Editor", button_count=2,
                     include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = StaticText("%s v%s - %s" % (PLUGIN_NAME, PLUGIN_VERSION, ADAPTER_NAME))
        self.pixmap = load_plugin_pixmap()
        self.menu_items = [
            (_("Stalker Portals"), _(
                "Manage /etc/enigma2/gtiptvplayer/stalker.txt"), "stalker"),
            (_("Xtream Playlists"), _(
                "Manage /etc/enigma2/gtiptvplayer/playlists.txt"), "playlists"),
            (_("Backup & Restore"), _("Create or restore configurations"), "backup"),
        ]
        self["menu"] = List([(a, b, self.pixmap, c)
                            for a, b, c in self.menu_items])
        self["Redkey"] = StaticText(_("Back"))
        self["Greenkey"] = StaticText(_("Select"))
        self["Yellowkey"] = StaticText("")
        self["Bluekey"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "HelpActions"], {
            "displayHelp": lambda: open_adapter_help(self.session, PLUGIN_ID),
            "ok": self.select_item,
            "green": self.select_item,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select_item(self):
        curr = self["menu"].getCurrent()
        if not curr:
            return
        tag = curr[3]
        if tag == "stalker":
            self.session.open(StalkerListScreen)
        elif tag == "playlists":
            self.session.open(PlaylistListScreen)
        elif tag == "backup":
            self.session.open(BackupRestoreScreen)


class StalkerListScreen(Screen):
    skin = list_skin("GTIPTV Stalker Portals", button_count=4, include_info=False,
                     button_names=["Redkey", "Greenkey", "Yellowkey", "Bluekey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.entries = []
        self.pixmap = load_plugin_pixmap()
        self["title"] = StaticText(
            "%s v%s - %s" % (PLUGIN_NAME, PLUGIN_VERSION, _("Stalker Portals")))
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add"))
        self["Yellowkey"] = StaticText(_("Edit"))
        self["Redkey"] = StaticText(_("Delete"))
        self["Bluekey"] = StaticText(_("Back"))
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "DirectionActions", "ChannelSelectBaseActions", "InfobarChannelSelection"], {
            "green": self.add_entry,
            "yellow": self.edit_entry,
            "red": self.delete_entry,
            "blue": self.close,
            "cancel": self.close,
            "ok": self.edit_entry,
            "channelUp": self.move_up,
            "channelDown": self.move_down,
            "nextBouquet": self.move_up,
            "prevBouquet": self.move_down,
        }, -1)
        self.onLayoutFinish.append(self.reload)

    def reload(self):
        data = load_all()
        self.entries = data.get("stalker", [])
        rows = [(item["url"], item["mac"], self.pixmap, idx)
                for idx, item in enumerate(self.entries)]
        self["menu"].setList(rows or [(_("No portals"), _(
            "Press Add to insert a new portal"), self.pixmap, None)])

    def add_entry(self):
        self.session.openWithCallback(
            self.reload, EditStalkerScreen, mode="add")

    def edit_entry(self):
        curr = self["menu"].getCurrent()
        if curr and curr[3] is not None:
            self.session.openWithCallback(
                self.reload, EditStalkerScreen, mode="edit", entry=self.entries[curr[3]], index=curr[3])

    def delete_entry(self):
        curr = self["menu"].getCurrent()
        if curr and curr[3] is not None:
            idx = curr[3]
            self.session.openWithCallback(lambda confirmed: self._confirm_delete(
                confirmed, idx), MessageBox, _("Delete this portal?"), MessageBox.TYPE_YESNO)

    def _confirm_delete(self, confirmed, idx):
        if confirmed:
            data = load_all()
            if idx < len(data["stalker"]):
                data["stalker"].pop(idx)
                save_all(data)
                self.reload()

    def move_up(self):
        self._move(-1)

    def move_down(self):
        self._move(1)

    def _move(self, delta):
        curr = self["menu"].getCurrent()
        if not curr or curr[3] is None:
            return
        idx = curr[3]
        target = idx + delta
        if 0 <= target < len(self.entries):
            data = load_all()
            data["stalker"][idx], data["stalker"][target] = data["stalker"][target], data["stalker"][idx]
            save_all(data)
            self.reload()
            self["menu"].setIndex(target)


class EditStalkerScreen(ConfigListScreen, Screen):
    skin = config_skin("Edit Stalker Portal")

    def __init__(self, session, mode="add", entry=None, index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.index = index
        entry = entry or {}
        self.url = ConfigText(default=entry.get(
            "url", "http://"), fixed_size=False)
        self.mac = ConfigText(default=entry.get(
            "mac", "00:1A:79:"), fixed_size=False)
        ConfigListScreen.__init__(self, [], session=session)

        screen_title = _("Add Portal") if mode == "add" else _("Edit Portal")
        self["title"] = StaticText("%s v%s - %s" %
                                   (PLUGIN_NAME, PLUGIN_VERSION, screen_title))

        self["Redkey"] = StaticText(_("Cancel"))
        self["Greenkey"] = StaticText(_("Save"))
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions", "InfobarEPGActions"], {
            "green": self.save,
            "ok": self.save,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Portal URL"), self.url),
            getConfigListEntry(_("MAC Address"), self.mac),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        curr = self["config"].getCurrent()
        if curr:
            lbl, field = curr
            self.session.openWithCallback(lambda val: self._keyboard_done(
                field, val), VirtualKeyBoard, title=_("Enter %s") % lbl, text=str(field.value))

    def _keyboard_done(self, field, val):
        if val is not None:
            field.value = val
            self["config"].invalidateCurrent()

    def save(self):
        try:
            norm_mac = normalize_mac(self.mac.value)
            norm_url = clean_text(self.url.value, "Portal URL")
            data = load_all()
            item = {"url": norm_url, "mac": norm_mac,
                    "id": make_id("stalker", norm_url, norm_mac)}
            if self.mode == "add":
                data["stalker"].append(item)
            else:
                data["stalker"][self.index] = item
            save_all(data)
            self.close(True)
        except Exception as e:
            self.session.open(MessageBox, str(e), MessageBox.TYPE_ERROR)


class PlaylistListScreen(Screen):
    skin = list_skin("GTIPTV Xtream Playlists", button_count=4, include_info=False,
                     button_names=["Redkey", "Greenkey", "Yellowkey", "Bluekey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.entries = []
        self.pixmap = load_plugin_pixmap()
        self["title"] = StaticText(
            "%s v%s - %s" % (PLUGIN_NAME, PLUGIN_VERSION, _("Xtream Playlists")))
        self["menu"] = List([])
        self["Greenkey"] = StaticText(_("Add"))
        self["Yellowkey"] = StaticText(_("Edit"))
        self["Redkey"] = StaticText(_("Delete"))
        self["Bluekey"] = StaticText(_("Back"))
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "DirectionActions", "ChannelSelectBaseActions", "InfobarChannelSelection"], {
            "green": self.add_entry,
            "yellow": self.edit_entry,
            "red": self.delete_entry,
            "blue": self.close,
            "cancel": self.close,
            "ok": self.edit_entry,
            "channelUp": self.move_up,
            "channelDown": self.move_down,
            "nextBouquet": self.move_up,
            "prevBouquet": self.move_down,
        }, -1)
        self.onLayoutFinish.append(self.reload)

    def reload(self):
        data = load_all()
        self.entries = data.get("playlists", [])
        rows = [("%s:%s" % (item["host"], item["port"]), "User: %s" %
                 item["username"], self.pixmap, idx) for idx, item in enumerate(self.entries)]
        self["menu"].setList(rows or [(_("No playlists"), _(
            "Press Add to insert a new playlist"), self.pixmap, None)])

    def add_entry(self):
        self.session.openWithCallback(
            self.reload, EditPlaylistScreen, mode="add")

    def edit_entry(self):
        curr = self["menu"].getCurrent()
        if curr and curr[3] is not None:
            self.session.openWithCallback(
                self.reload, EditPlaylistScreen, mode="edit", entry=self.entries[curr[3]], index=curr[3])

    def delete_entry(self):
        curr = self["menu"].getCurrent()
        if curr and curr[3] is not None:
            idx = curr[3]
            self.session.openWithCallback(lambda confirmed: self._confirm_delete(
                confirmed, idx), MessageBox, _("Delete this playlist?"), MessageBox.TYPE_YESNO)

    def _confirm_delete(self, confirmed, idx):
        if confirmed:
            data = load_all()
            if idx < len(data["playlists"]):
                data["playlists"].pop(idx)
                save_all(data)
                self.reload()

    def move_up(self):
        self._move(-1)

    def move_down(self):
        self._move(1)

    def _move(self, delta):
        curr = self["menu"].getCurrent()
        if not curr or curr[3] is None:
            return
        idx = curr[3]
        target = idx + delta
        if 0 <= target < len(self.entries):
            data = load_all()
            data["playlists"][idx], data["playlists"][target] = data["playlists"][target], data["playlists"][idx]
            save_all(data)
            self.reload()
            self["menu"].setIndex(target)


class EditPlaylistScreen(ConfigListScreen, Screen):
    skin = config_skin("Edit Xtream Playlist")

    def __init__(self, session, mode="add", entry=None, index=None):
        Screen.__init__(self, session)
        self.mode = mode
        self.index = index
        self.entry = entry or {}
        self.host = ConfigText(default=self.entry.get(
            "host", "http://"), fixed_size=False)
        self.port = ConfigText(default=str(
            self.entry.get("port", "80")), fixed_size=False)
        self.username = ConfigText(default=self.entry.get(
            "username", ""), fixed_size=False)
        self.password = ConfigText(default=self.entry.get(
            "password", ""), fixed_size=False)
        self.type = ConfigSelection(default=self.entry.get("type", "m3u_plus"), choices=[
                                    ("m3u_plus", "m3u_plus"), ("m3u", "m3u")])
        self.output = ConfigSelection(default=self.entry.get(
            "output", "ts"), choices=[("ts", "ts"), ("m3u8", "m3u8")])
        ConfigListScreen.__init__(self, [], session=session)

        screen_title = _("Add Playlist") if mode == "add" else _(
            "Edit Playlist")
        self["title"] = StaticText("%s v%s - %s" %
                                   (PLUGIN_NAME, PLUGIN_VERSION, screen_title))

        self["Redkey"] = StaticText(_("Cancel"))
        self["Greenkey"] = StaticText(_("Save"))
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions", "InfobarEPGActions"], {
            "green": self.save,
            "ok": self.save,
            "red": self.close,
            "cancel": self.close,
            "info": self.open_keyboard,
        }, -1)
        self.create_setup()

    def create_setup(self):
        self.list = [
            getConfigListEntry(_("Server URL / Host"), self.host),
            getConfigListEntry(_("Port"), self.port),
            getConfigListEntry(_("Username"), self.username),
            getConfigListEntry(_("Password"), self.password),
            getConfigListEntry(_("Type"), self.type),
            getConfigListEntry(_("Output"), self.output),
        ]
        self["config"].setList(self.list)

    def open_keyboard(self):
        curr = self["config"].getCurrent()
        if curr:
            lbl, field = curr
            self.session.openWithCallback(lambda val: self._keyboard_done(
                field, val), VirtualKeyBoard, title=_("Enter %s") % lbl, text=str(field.value))

    def _keyboard_done(self, field, val):
        if val is not None:
            field.value = val
            self["config"].invalidateCurrent()

    def save(self):
        try:
            h = clean_text(self.host.value, "Host URL")
            p = clean_text(self.port.value, "Port")
            u = clean_text(self.username.value, "Username")
            pwd = self.password.value.strip(
            ) if self.password.value else self.entry.get("password", "")
            if self.mode == "add" and not pwd:
                raise ValidationError("Password is required")
            item = {
                "id": self.entry.get("id") or make_id("playlist", h, p, u),
                "host": h,
                "port": p,
                "username": u,
                "password": pwd,
                "type": self.type.value,
                "output": self.output.value,
            }
            data = load_all()
            if self.mode == "add":
                data["playlists"].append(item)
            else:
                data["playlists"][self.index] = item
            save_all(data)
            self.close(True)
        except Exception as e:
            self.session.open(MessageBox, str(e), MessageBox.TYPE_ERROR)


class BackupRestoreScreen(Screen):
    skin = list_skin("GTIPTV Backup & Restore", button_count=2,
                     include_info=False, button_names=["Redkey", "Greenkey"])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.pixmap = load_plugin_pixmap()
        self.menu_entries = [
            (_("Backup configurations"), "Create backup archive", "backup"),
            (_("Restore configurations"), "Restore an existing backup", "restore"),
        ]
        self["title"] = StaticText(
            "%s v%s - %s" % (PLUGIN_NAME, PLUGIN_VERSION, _("Backup & Restore")))
        self["menu"] = List([(a, b, self.pixmap, c)
                            for a, b, c in self.menu_entries])
        self["Greenkey"] = StaticText(_("Select"))
        self["Redkey"] = StaticText(_("Back"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.select,
            "green": self.select,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def select(self):
        curr = self["menu"].getCurrent()
        if not curr:
            return
        if curr[3] == "backup":
            f = create_backup()
            self.session.open(MessageBox, "Backup saved: %s" %
                              f, MessageBox.TYPE_INFO)
        else:
            backups = [(b, b) for b in list_backups()]
            if not backups:
                self.session.open(
                    MessageBox, "No backups found", MessageBox.TYPE_WARNING)
                return
            self.session.openWithCallback(
                self._restore_file, ChoiceBox, title="Select backup", list=backups)

    def _restore_file(self, choice):
        if choice:
            restore_backup(choice[1])
            self.session.open(
                MessageBox, "Restored successfully", MessageBox.TYPE_INFO)


def manifest():
    return {
        "id": PLUGIN_ID,
        "name": ADAPTER_NAME,
        "description": PLUGIN_DESCRIPTION,
        "web_path": PLUGIN_WEB_PATH,
        "version": PLUGIN_VERSION,
    }


def initialize():
    ensure_files()


def open_main(session):
    session.open(GTIPTVMainMenuScreen)


def web_get(endpoint, args):
    if endpoint == "info":
        res = manifest()
        res.update(
            {"success": True, "source_plugin_dir": SOURCE_PLUGIN_DIR, "config_dir": CONFIG_DIR})
        return res
    if endpoint == "data":
        res = load_all()
        res["success"] = True
        return res
    if endpoint == "backups":
        return {"success": True, "backups": list_backups()}
    raise ValidationError("Unknown endpoint")


def web_post(endpoint, data):
    if endpoint == "update":
        res = save_all(data, expected_rev=data.get("revision"))
        res["success"] = True
        return res
    if endpoint == "backup":
        return {"success": True, "backup": create_backup()}
    if endpoint == "restore":
        res = restore_backup(data.get("backup"))
        res["success"] = True
        return res
    raise ValidationError("Unknown endpoint")
