#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Readable About and Help screens for MyWebUIController receiver UI.

INFO and HELP are remote-control shortcuts.  They remain intentionally hidden
from the colored-key footer so the receiver screens stay clean and uncluttered.
"""

from __future__ import print_function

from Components.ActionMap import ActionMap
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Screens.Screen import Screen

try:
    from Tools.International import _
except Exception:
    def _(txt):
        return txt

from .ui_horizontal import screen_profile, xml_attr


CONTROLLER_VERSION = "1.0.0"


def text_screen_skin(title):
    """Create a spacious reading screen with a visible RED Close action."""
    p = screen_profile()
    w, h, m = p["w"], p["h"], p["margin"]
    key_y = h - p["keyh"] - 16
    return """
    <screen position="center,center" size="%(w)s,%(h)s" title="%(title)s">
        <widget name="text" position="%(m)s,%(m)s" size="%(cw)s,%(ch)s" font="Regular;%(font)s" />
        <widget source="Redkey" render="Label" position="%(m)s,%(ky)s" size="%(kw)s,%(kh)s" font="Regular;%(small)s" halign="center" valign="center" foregroundColor="white" transparent="1" />
        <eLabel backgroundColor="#cc2222" position="%(m)s,%(liney)s" size="%(kw)s,5" />
    </screen>
    """ % {
        "w": w,
        "h": h,
        "title": xml_attr(title),
        "m": m,
        "cw": w - 2 * m,
        "ch": key_y - m - 8,
        "font": p["small"],
        "small": p["small"],
        "ky": key_y,
        "kw": p["keyw"],
        "kh": p["keyh"],
        "liney": key_y + p["keyh"] + 2,
    }


def _section(title, lines):
    return ["", "=" * 68, title, "=" * 68] + list(lines)


ABOUT_TEXT = "\n".join([
    "MYWEBUICONTROLLER",
    "Subscription Management Center for Enigma2",
    "",
    "Version      : %s" % CONTROLLER_VERSION,
    "Developed by : MNASR",
    "Year         : 2026",
    "",
    "------------------------------------------------------------",
    "SPECIAL THANKS",
    "------------------------------------------------------------",
    "Thanks to the developers of all supported plugins.",
    "Their work made these integrations possible.",
    "",
    "One controller. One Web UI. A cleaner receiver experience.",
])


GENERAL_HELP_LINES = [
    "MYWEBUICONTROLLER HELP CENTER",
    "Subscription control made simple, organized and receiver-friendly.",
]
GENERAL_HELP_LINES += _section("1. WHAT THIS PLUGIN DOES", [
    "MyWebUIController brings supported subscription editors together in one place.",
    "Use the receiver interface for quick edits or open the shared Web UI from a browser.",
])
GENERAL_HELP_LINES += _section("2. MAIN SCREEN", [
    "OK       Open the selected adapter.",
    "RED      Disable the shared Web UI server.",
    "GREEN    Enable the shared Web UI server.",
    "YELLOW   Reserved for a future function.",
    "BLUE     Open controller settings.",
    "CH+      Move the selected adapter upward when rearrangement is enabled.",
    "CH-      Move the selected adapter downward when rearrangement is enabled.",
    "         The new supported-plugin order is saved automatically.",
    "INFO     Open the About screen.",
    "HELP     Open this Help Center.",
])
GENERAL_HELP_LINES += _section("3. CONTROLLER SETTINGS", [
    "Web Interface Port        Choose the shared browser port.",
    "Start Automatically       Start the Web UI with Enigma2 when enabled.",
    "Backup Directory          Use one shared location for adapter backups.",
    "Web UI Theme              Choose Light or Dark appearance.",
    "Plugin List Rearrangement Enable or disable CH+/CH- adapter ordering.",
    "Check for Updates          Highlight the row and press OK to check GitHub.",
    "",
    "Saving settings does not start, stop or restart the Web UI server.",
    "Updating is separate: highlight Check for Updates and press OK.",
    "Use RED and GREEN on the main screen when you need to restart the listener.",
])
GENERAL_HELP_LINES += _section("4. WEB UI", [
    "Open the URL shown on the main screen from a browser on your local network.",
    "The home page lists every supported adapter in the saved receiver order.",
    "Rearrange adapters with CH+/CH- on the receiver main screen.",
    "Use the Dark Theme / Light Theme button to switch appearance instantly.",
    "Use UP and DOWN controls where available to save a preferred item order.",
])
GENERAL_HELP_LINES += _section("5. BACKUP & RESTORE", [
    "Every supported adapter creates its own backup file.",
    "All backup files use the shared directory configured in controller settings.",
    "Create a backup before making major subscription changes.",
])
GENERAL_HELP_LINES += _section("6. SUPPORTED ADAPTERS", [
    "MyHybridIPTV        M3U, Stalker and Xtream subscription records.",
    "XStreamity          Xtream playlist entries.",
    "EStalker            Portal and MAC-address pairs.",
    "IPaudioPro          Stream groups and grouped stream items.",
    "IPaudioPlus         Channel groups and grouped channel items.",
    "BouquetMakerXtream  Xtream playlist entries.",
    "IPStreamer          Additional stream playlist entries.",
])
GENERAL_HELP_LINES += _section("7. GOOD PRACTICE", [
    "Keep a recent backup before large edits.",
    "After browser edits, press Save Changes before closing the page.",
    "Use the Web UI only inside your trusted local network.",
])


ADAPTER_HELP = {
    "myhybridiptv": (
        "MYHYBRIDIPTV",
        [
            "Manage M3U playlists, Stalker portals and Xtream Codes.",
            "Receiver actions: Add, Edit and Delete.",
            "Web UI actions: UP, DOWN, Edit, Delete and Save Changes.",
            "Backup & Restore creates one bundle for the MyHybridIPTV files.",
        ],
    ),
    "xstreamity": (
        "XSTREAMITY",
        [
            "Manage structured Xtream playlist entries.",
            "Edit URL, port, username, password, type and output values.",
            "Use Web UI UP and DOWN controls to arrange playlist order.",
        ],
    ),
    "estalker": (
        "ESTALKER",
        [
            "Manage portal URLs and MAC addresses.",
            "MAC addresses may be typed with or without colons.",
            "Saved values are normalized to uppercase colon format.",
            "Use Web UI UP and DOWN controls to arrange server order.",
        ],
    ),
    "ipaudiopro": (
        "IPAUDIOPRO",
        [
            "Manage stream groups and the stream items inside each group.",
            "The Web UI can arrange groups and streams with UP and DOWN controls.",
            "A stream stays inside its selected group while being reordered.",
        ],
    ),
    "ipaudioplus": (
        "IPAUDIOPLUS",
        [
            "Manage channel groups and the channels inside each group.",
            "The Web UI can arrange groups and channels with UP and DOWN controls.",
            "A channel stays inside its selected group while being reordered.",
        ],
    ),
    "bmx": (
        "BOUQUETMAKERXTREAM",
        [
            "Manage structured Xtream playlist entries for BouquetMakerXtream.",
            "Edit URL, port, username, password, type and output values.",
            "Use Web UI UP and DOWN controls to arrange playlist order.",
        ],
    ),
    "ipstreamer": (
        "IPSTREAMER",
        [
            "Manage additional IPStreamer playlist entries.",
            "Each entry contains a channel name and stream URL.",
            "Use Web UI UP and DOWN controls to arrange playlist order.",
        ],
    ),
}


class _ScrollableTextScreen(Screen):
    """Base class for eye-friendly informational screens."""

    def __init__(self, session, title, content):
        self.skin = text_screen_skin(title)
        Screen.__init__(self, session)
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel(content)
        self["actions"] = ActionMap(
            ["DirectionActions", "ColorActions", "OkCancelActions"],
            {
                "cancel": self.close,
                "ok": self.close,
                "red": self.close,
                "up": self["text"].pageUp,
                "down": self["text"].pageDown,
                "left": self["text"].pageUp,
                "right": self["text"].pageDown,
            },
            -1,
        )
        self.setTitle(title)


class AboutScreen(_ScrollableTextScreen):
    def __init__(self, session):
        _ScrollableTextScreen.__init__(self, session, "About MyWebUIController", ABOUT_TEXT)


class HelpScreen(_ScrollableTextScreen):
    def __init__(self, session, adapter_id=None):
        lines = list(GENERAL_HELP_LINES)
        adapter = ADAPTER_HELP.get(adapter_id)
        if adapter:
            lines += _section("CURRENT ADAPTER: %s" % adapter[0], adapter[1])
        lines += ["", "Use UP and DOWN to scroll. Press RED, OK or EXIT to close."]
        _ScrollableTextScreen.__init__(self, session, "MyWebUIController Help", "\n".join(lines))


def open_adapter_help(session, adapter_id):
    """Open the shared help center with adapter-specific guidance appended."""
    session.open(HelpScreen, adapter_id)
